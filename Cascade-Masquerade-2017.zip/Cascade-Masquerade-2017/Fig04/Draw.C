{
#include "stdio.h"
#include "stdlib.h"
#include "math.h"

    gROOT->Reset();
    gStyle->SetOptStat(0);
    gStyle->SetPalette(1);
    gStyle->SetCanvasColor(1);
    gStyle->SetFrameFillColor(1);
    TCanvas *c1 = new TCanvas("c1","Diffuse Gamma Spectra",10,10,1100,900);
    c1->GetFrame()->SetBorderMode(-1);
    c1->SetFillColor(0);
    c1->SetLogy();
//
    const Int_t nz= 18600;
    int i;
    double rd;
    double z1[nz],w1[nz];
    double z2[nz],w2[nz];
    double z3[nz],w3[nz];
    double z4[nz],w4[nz];
    FILE *fp;
//
    h= new TH2F("","",30,0.0,0.2,30,0.8,100.0);
    h->SetTitle("");
    h->GetXaxis()->SetTitle("z");
    h->GetYaxis()->SetTitle("w(z)/w(0)");
    h->GetXaxis()->SetTitleOffset(1.0);
    h->GetYaxis()->SetTitleOffset(1.1);
    h->SetStats(kFALSE);
    h->Draw();
//
    fp= fopen("weight-10PeV","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
    fscanf(fp,"%lf",&rd); //E_{p0}
    for (i=0; i<nz; i++)
    {
	fscanf(fp,"%lf",&rd); z1[i]= rd;
	fscanf(fp,"%lf",&rd); w1[i]= rd;
	//printf("%13.6e %13.6e\n",z1[i],w1[i]);
    }
    fclose(fp);
//
    gr1 = new TGraph(nz,z1,w1);
    gr1->SetLineColor(1);
    gr1->SetLineWidth(2);
    gr1->Draw("L");
//
    fp= fopen("weight-30PeV","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
    fscanf(fp,"%lf",&rd); //E_{p0}
    for (i=0; i<nz; i++)
    {
	fscanf(fp,"%lf",&rd); z2[i]= rd;
	fscanf(fp,"%lf",&rd); w2[i]= rd;
	//printf("%13.6e %13.6e\n",z1[i],w1[i]);
    }
    fclose(fp);
//
    gr2 = new TGraph(nz,z2,w2);
    gr2->SetLineColor(2);
    gr2->SetLineWidth(2);
    gr2->Draw("L");
//
    fp= fopen("weight-50PeV","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
    fscanf(fp,"%lf",&rd); //E_{p0}
    for (i=0; i<nz; i++)
    {
	fscanf(fp,"%lf",&rd); z3[i]= rd;
	fscanf(fp,"%lf",&rd); w3[i]= rd;
	//printf("%13.6e %13.6e\n",z1[i],w1[i]);
    }
    fclose(fp);
//
    gr3 = new TGraph(nz,z3,w3);
    gr3->SetLineColor(3);
    gr3->SetLineWidth(2);
    gr3->Draw("L");
//
    fp= fopen("weight-100PeV","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
    fscanf(fp,"%lf",&rd); //E_{p0}
    for (i=0; i<nz; i++)
    {
	fscanf(fp,"%lf",&rd); z4[i]= rd;
	fscanf(fp,"%lf",&rd); w4[i]= rd;
	//printf("%13.6e %13.6e\n",z1[i],w1[i]);
    }
    fclose(fp);
//
    gr4 = new TGraph(nz,z4,w4);
    gr4->SetLineColor(4);
    gr4->SetLineWidth(2);
    gr4->Draw("L");
//
    c1->Update();
    c1->GetFrame()->SetFillColor(0);
    c1->GetFrame()->SetBorderMode(0);
    c1->GetFrame()->SetBorderSize(0);
    c1->SaveAs("Fig04.eps");
    c1->SaveAs("Fig04.jpg");
    if (gSystem->ProcessEvents()) break;
    c1->Modified();
}
