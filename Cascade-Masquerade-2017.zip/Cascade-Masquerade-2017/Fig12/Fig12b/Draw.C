{
#include "stdio.h"
#include "stdlib.h"
#include "math.h"
// 1. Init
    gROOT->Reset();
    gStyle->SetOptStat(0);
    gStyle->SetPalette(1);
    gStyle->SetCanvasColor(1);
    gStyle->SetFrameFillColor(1);
    TCanvas *c1 = new TCanvas("c1","Exp. and Model Gamma Spectra",10,10,1100,900);
    c1->GetFrame()->SetBorderMode(-1);
    c1->SetFillColor(0);
    c1->SetLogx();
    c1->SetLogy();
// 2. Define constants
    const Int_t NExpMax= 100;
    const Int_t NModMax= 1000;
    const Int_t PrintFlag= 0;
// 3. Define variables
    int i,NExp,NExp2,NMod,NMod2;
    double rd,K,K2;
    double statp,statm,sysp,sysm;
    double chisq;
    FILE *fp;
// exp. data 1
    Double_t EExp[NExpMax],SEDExp[NExpMax]; //exp. data
    Double_t EErr[NExpMax],SEDErr[NExpMax];
    Double_t SysExpP[NExpMax],SysExpM[NExpMax];
// model data
    Double_t EMod[NModMax],SEDMod[NModMax]; //model
    Double_t SEDAbs[NModMax],SEDCasc[NModMax],SEDPrim[NModMax];
// 4. Init variables
// init exp. data
    for (i=0; i<NExpMax; i++)
    {
	EExp[i]  = 0.0;
	SEDExp[i]= 0.0;
//
	EErr[i]= 0.0;
	SEDErr[i]= 0.0;
//
	SysExpP[i]= 0.0;
	SysExpM[i]= 0.0;
    }
// init model data
    for (i=0; i<NModMax; i++)
    {
	EMod[i]  = 0.0;
	SEDMod[i]= 0.0;
	SEDAbs[i]= 0.0;
	SEDCasc[i]= 0.0;
	SEDPrim[i]= 0.0;
    }
// 5. read exp. data 1
    fp= fopen("080-Aharonian07b","r");
    if (fp==NULL)
    {
	printf("Error: exp. input file not found!\n");
	return;
    }
    fscanf(fp,"%d",&NExp);
    if (PrintFlag>0)
	printf("NExp= %4d\n",NExp);
    for (i=0; i<NExp; i++)
    {
	fscanf(fp,"%lf",&rd);
	EExp[i]= rd;
	fscanf(fp,"%lf",&rd); //emin
	fscanf(fp,"%lf",&rd);
	fscanf(fp,"%lf",&rd);
	SEDExp[i]= EExp[i]*EExp[i]*rd; //E^2*dN/dE
//
	fscanf(fp,"%lf",&rd); //statistical uncertainty
	statp= rd;
	fscanf(fp,"%lf",&rd);
	statm= fabs(rd);
	SEDErr[i]= EExp[i]*EExp[i]*rd;
	fscanf(fp,"%lf",&rd); //systematic  uncertainty +
	sysp= rd;
	SysExpP[i]= EExp[i]*EExp[i]*sqrt(statp*statp+sysp*sysp);
	fscanf(fp,"%lf",&rd); //systematic  uncertainty -
	sysm= fabs(rd);
	SysExpM[i]= EExp[i]*EExp[i]*sqrt(statm*statm+sysm*sysm);
	printf("%8.6e %8.6e  %8.6e %8.6e\n",EExp[i],SEDExp[i],SysExpM[i],SysExpP[i]);
    }
    fclose(fp);
// 6. read model data
    K=7.8e-17;
    fp= fopen("Approx-080-new","r");
    if (fp==NULL)
    {
	printf("Error: model input file not found!\n");
	return;
    }
    fscanf(fp,"%d",&NMod);
    if (PrintFlag>0)
	printf("NMod= %4d\n",NMod);
    for (i=0; i<NMod; i++)
    {
	fscanf(fp,"%lf",&rd);
	EMod[i]= rd;
	fscanf(fp,"%lf",&rd);
	SEDMod[i]=K*rd;
	fscanf(fp,"%lf",&rd);
	SEDAbs[i]=K*rd;
	fscanf(fp,"%lf",&rd);
	SEDCasc[i]=K*rd;
	fscanf(fp,"%lf",&rd);
	SEDPrim[i]=K*rd;
	if (PrintFlag>0)
	    printf("%8.6e %8.6e\n",EMod[i],SEDMod[i]);
    }
    fclose(fp);
// 7. Draw histogram to zoom graphs
    h= new TH2F("","",30,0.2,6.0,30,2.0e-14,8.0e-12);
    h->GetXaxis()->SetTitle("E [TeV]");
    h->GetYaxis()->SetTitle("SED [TeVcm^{-2}s^{-1}]");
    h->GetXaxis()->SetTitleOffset(1.4);
    h->GetYaxis()->SetTitleOffset(1.4);
    h->SetStats(kFALSE);
    h->Draw();
// 8. Draw exp. data 1
    GrExp = new TGraphAsymmErrors(NExp,EExp,SEDExp,0,0,SysExpM,SysExpP);
    GrExp->SetLineColor(2);		//for line
    GrExp->SetLineWidth(2);		//mode
    GrExp->SetMarkerColor(2);		//2= red
    GrExp->SetTitle("");
    GrExp->SetMarkerStyle(8);		//8= circles
    GrExp->SetMarkerSize(1.5);
    GrExp->Draw("P");
// 9. Draw model data
    FILE *fpout;
    fpout= fopen("Output","w");
    for (i=0; i<NMod; i++)
	fprintf(fpout,"%13.6e %13.6e\n",EMod[i],SEDMod[i]);
    fclose(fpout);
//
    GrMod = new TGraph(NMod,EMod,SEDMod);
    GrMod->SetLineColor(4);		//for line
    GrMod->SetLineWidth(2);		//mode
    GrMod->SetTitle("");
    GrMod->Draw("L");
    //
    GrModAbs = new TGraph(NMod,EMod,SEDAbs);
    GrModAbs->SetLineColor(1);		//for line
    GrModAbs->SetLineWidth(2);		//mode
    GrModAbs->SetTitle("");
    GrModAbs->Draw("L");
    //
    GrModCasc = new TGraph(NMod,EMod,SEDCasc);
    GrModCasc->SetLineColor(3);		//for line
    GrModCasc->SetLineWidth(2);		//mode
    GrModCasc->SetTitle("");
    GrModCasc->Draw("L");
    //
    GrModPrim = new TGraph(NMod,EMod,SEDPrim);
    GrModPrim->SetLineColor(1);		//for line
    GrModPrim->SetLineWidth(2);		//mode
    GrModPrim->SetLineStyle(9);		//mode
    GrModPrim->SetTitle("");
    GrModPrim->Draw("L");
    //
    c1->Update();
    c1->GetFrame()->SetFillColor(0);
    c1->GetFrame()->SetBorderMode(0);
    c1->GetFrame()->SetBorderSize(0);
    c1->SaveAs("Fig12b.eps");
    c1->SaveAs("Fig12b.jpg");
    if (gSystem->ProcessEvents()) break;
    c1->Modified();
}
