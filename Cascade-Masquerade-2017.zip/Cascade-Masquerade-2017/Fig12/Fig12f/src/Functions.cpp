double linear_ext(double x1, double x2, double y1, double y2, double x)
{
    double A, B;

    A = (y2 - y1) / (x2 - x1);
    B = y1 - A * x1;

    return (A * x + B);
}

void exponent(int N, double *E, double *f, double *g, int mode)
{
    //f(E) = g(E) * exp(k*tau)

    double A, B, tau0, k;

    if (mode >= 0) k = 1;
    else k = -1;

    for (int i = 0; i < N; i++)
            {
                A = 0, B = 0;
                for (int j = 0; j < n_E - 1; j++)
                    if ((E[i] >= E_tau[j])&&(E[i] < E_tau[j+1]))
                        tau0 = linear_ext(E_tau[j], E_tau[j+1], tau[j], tau[j+1], E[i]);
                f[i] = g[i] * exp(k * tau0);
            }
}

