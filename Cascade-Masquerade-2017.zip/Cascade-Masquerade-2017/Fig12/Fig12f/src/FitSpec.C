//#include "TMinuit.h"
#include "src/Functions.cpp"

#define NPAR		4   //number of fitting parameters
#define NLIST		10  //max. lenght of argument list
#define PrintFlag	0

TMinuit *gMinuit;
Int_t ierflg; //error flag for Minuit
Double_t arglist[NLIST]; //argument list for Minuit


void FitSpec()
{

    static Double_t vstart[NPAR]; //starting values of parameters for Minuit
    static Double_t step[NPAR]; //starting step values of parameters for Minuit

    double tmpd;

    vstart[0]= 1; //gamma
    step[0]  = 0.01;
    vstart[1]= 1; //E_c
    step[1]  = 1;
    vstart[2]= 1; //L_abs
    step[2]  = 0.01;
    vstart[3]= 1; //L_sec
    step[3]  = 0.01;

    //Initialize TMinuit with a maximum of NPAR parameters:
    gMinuit = new TMinuit(NPAR);
    gMinuit->SetFCN(FitFunc); //set function to fit
    ierflg = 0;
    arglist[0] = 1.0; //1.0 for chi-square fit (one standard deviation)
    gMinuit->mnexcm("SET ERR",arglist,1,ierflg); //Minuit execute command; 1 argument
    gMinuit->mnparm(0,"a1",vstart[0],step[0],0,10,ierflg); //set params
    gMinuit->mnparm(1,"a2",vstart[1],step[1],0,1000000000,ierflg); //set params
    gMinuit->mnparm(2,"a3",vstart[2],step[2],0,0,ierflg); //set params
    gMinuit->mnparm(3,"a4",vstart[3],step[3],0,0,ierflg); //set params

// ok

    arglist[0] = 5000.0; //max number of calls
    arglist[1] = 1.0; //tolarance parameter
    gMinuit->mnexcm("MIGRAD",arglist,4,ierflg); //4 arguments

    GetResults();

    cout << "gamma = " << gamma << endl;
    cout << "Ec = " << Ec << endl;
    cout << "L_abs = " << L_abs << endl;
    cout << "L_sec = " << L_sec << endl;

}


void GetResults()
{

    Int_t NVPar,NParx,ICStat;
    Double_t ErrMin,EDm,ErrDef;
    double ErrPar[NPAR]; //optimized parameter uncertainies
    double LowLim[NPAR],UpLim[NPAR],Var[NPAR];	//parameter limits; variability flag
//
    gMinuit->mnstat(ErrMin,EDm,ErrDef,NVPar,NParx,ICStat);
    if (PrintFlag>0)
	gMinuit->mnprin(3,ErrMin);
//get parameters
    gMinuit->mnpout(0,"a1",gamma,ErrPar[0],LowLim[0],UpLim[0],Var[0]);
    gMinuit->mnpout(1,"a2",Ec,ErrPar[0],LowLim[0],UpLim[0],Var[0]);
    gMinuit->mnpout(2,"a3",L_abs,ErrPar[0],LowLim[0],UpLim[0],Var[0]);
    gMinuit->mnpout(3,"a4",L_sec,ErrPar[0],LowLim[0],UpLim[0],Var[0]);

    chisq_min = ErrMin;
}

//The function to optimize is FitFunc (!!!!!)
//see DESY presentation Minuit.pdf, slide 5
void FitFunc(int &npar, double *gin, double &f,double *par, int iflag)
{
    double S_full[nbin];
    double chisq = 0;
    double tmpd = 0;

    //gamma <=> par[0]
    //Ec <=> par[1]
    //L_abs <=> par[2]
    //L_sec <=> par[3]

    for (int i = 0; i < nbin; i++)
        S0_mod[i] = pow(E_exp[i],2 - par[0]) * exp(-E_exp[i]/par[1]);
    exponent(nbin, E_exp, S_mod, S0_mod, -1);
    tmpd = 0;
    for (int i = 0; i < nbin; i++)
        tmpd += S_mod[i];
    for (int i = 0; i < nbin; i++)
        S_mod[i] /= tmpd;
    for (int i = 0; i < nbin; i++)
        for (int j = 0; j < nbin2 - 1; j++)
            if ((E_exp[i] >= E_2[j])&&(E_exp[i] < E_2[j + 1]))
                S_full[i] = par[2] * S_mod[i] + par[3] * S_2[j];

    for (int i = 0; i < nbin; i++)
        if (S_stat[i] != 0) chisq += pow( (S_exp[i] - S_full[i])/S_stat[i], 2);
            else chisq += pow(S_exp[i] - S_full[i], 2);
    f = chisq;
}
