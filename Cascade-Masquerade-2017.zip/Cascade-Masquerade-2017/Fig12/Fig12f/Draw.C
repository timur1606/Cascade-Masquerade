#include "src/ReadData.cpp"
#include "src/FitSpec.C"
#include "src/DrawGraph.C"
#include "src/Functions.cpp"

    double z0;
    const int nbin;
    double *E_exp;
    double *S_exp;
    double *S_stat_p, *S_stat_m, *S_stat;
    double norm_exp = 0;

    double gamma,Ec;
    double *S0_mod, *S_mod;
    double L_abs;
    double norm_mod = 0;

    double *E_2, *S_2;
    const int nbin2 = 100;
    int N;
    double L_sec = 1;

    double weight;
    double z;
    double z_w[1860], w[1860];

    int n_E;
    double *E_tau, *tau;

    double chisq_min;

    char graph_title[50], name_graph[50], name_file[50];

void Draw()
{
    ReadData();
    FitSpec();
    DrawGraph();
}
