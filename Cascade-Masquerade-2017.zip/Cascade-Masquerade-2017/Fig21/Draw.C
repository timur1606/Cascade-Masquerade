{
#include "stdio.h"
#include "stdlib.h"
#include "math.h"

    gROOT->Reset();
    gStyle->SetOptStat(0);
    gStyle->SetPalette(1);
    gStyle->SetCanvasColor(1);
    gStyle->SetFrameFillColor(1);
    TCanvas *c1 = new TCanvas("c1","Diffuse Gamma Spectra",10,10,1100,900);
    c1->GetFrame()->SetBorderMode(-1);
    c1->SetFillColor(0);
    c1->SetLogx();
    c1->SetLogy();
//
    const Int_t nc= 401;
    const Int_t ne= 100;
    const Int_t nb= 5;
    const Int_t PrintFlag= 0;
//
    int i,j,k,ncol1,ncol2,NExp;
    double rd;
    double Ec[nc],SEDc[nc]; //combined SED
//
    int nbe,test;
    double zs,delta;
    double B0[nb];
    double Ee[ne],Emin[ne],Emax[ne],ObsSpec[ne];
    double StatP[ne],StatM[ne],SystP[ne],SystM[ne];
    double EErr[ne],SEDErrP[ne],SEDErrM[ne];
//
    double ObsSED[ne],DeltaObsSED[ne];
//
    int nmin;
    double chi2,p,Z;
    double delta,min,FOpt;
//
    FILE *fp;
    FILE *fpt;
//
    fp= fopen("071-Aliu14a","r");
    if (fp==NULL)
    {
	printf("Error: exp. input file not found!\n");
	return;
    }
//
    fscanf(fp,"%d",&nbe);
    fscanf(fp,"%lf",&zs);
    for (i=0; i<nbe; i++)
    {
	fscanf(fp,"%lf",&rd); Ee[i]     = rd;			//energy
	fscanf(fp,"%lf",&rd); Emin[i]   = rd;			//min energy
	fscanf(fp,"%lf",&rd); Emax[i]   = rd;			//max energy
	fscanf(fp,"%lf",&rd); ObsSpec[i]= rd;			//intensity (dN/dE)
	fscanf(fp,"%lf",&rd); StatP[i]  = rd;			//statistical uncertainty
	fscanf(fp,"%lf",&rd); StatM[i]  = rd;			//statistical uncertainty
	fscanf(fp,"%lf",&rd); SystP[i]  = rd;			//systematic uncertainty (+)
	fscanf(fp,"%lf",&rd); SystM[i]  = rd;			//systematic uncertainty (-)
    }
    fclose(fp);
//
    for (i=0; i<nbe; i++)
    {
	EErr[i]= 0.0;
	delta= (fabs(StatP[i])+fabs(StatM[i]))/2.0;
	ObsSED[i]     = Ee[i]*Ee[i]*ObsSpec[i];
	SEDErrP[i]    = Ee[i]*Ee[i]*fabs(StatP[i]);
	SEDErrM[i]    = Ee[i]*Ee[i]*fabs(StatM[i]);
	DeltaObsSED[i]= Ee[i]*Ee[i]*delta;
    }
    for (i=0; i<nbe; i++)
	Ee[i]= Ee[i];
//
    h= new TH2F("","",30,1.0e-2,2.0e1,30,1.0e-15,5.0e-12);
    h->SetTitle("");
    h->GetXaxis()->SetTitle("E [TeV]");
    h->GetYaxis()->SetTitle("SED [TeVcm^{-2}s^{-1}]");
    h->GetXaxis()->SetTitleOffset(1.4);
    h->GetYaxis()->SetTitleOffset(1.4);
    h->SetStats(kFALSE);
    h->Draw();
//
    GrExp = new TGraphAsymmErrors(nbe,Ee,ObsSED,EErr,EErr,SEDErrM,SEDErrP);
    GrExp->SetLineColor(2);			//for line mode
    GrExp->SetLineWidth(2);			
    GrExp->SetMarkerColor(2);			//2= red
    GrExp->SetMarkerStyle(8);			//
    GrExp->SetMarkerSize(2.0);
    GrExp->Draw("P");				//markers
//
    fp= fopen("ModFactor-5","r");
    if (fp==NULL)
    {
	printf("Error: model input file not found!\n");
	return;
    }
    fpt= fopen("TestP","w");
    for (k=0; k<nb; k++)
    {
    fscanf(fp,"%lf",&rd); B0[k]= rd;
    for (i=0; i<nc; i++)
    {
	fscanf(fp,"%lf",&rd); Ec[i]= 1.0e-12*rd;
	fscanf(fp,"%lf",&rd); SEDc[i]= rd;
    }
//
    nmin= 0;
    chi2= 0.0;
    for (i=0; i<nbe; i++)
    {
	FOpt= 0.0;
	min= 1.0e40;
	for (j=0; j<nc; j++)
	{
	    delta= fabs(Ee[i]-Ec[j]);
	    if (delta<min)
	    {
		min= delta;
		nmin= j;
		FOpt= SEDc[j];
	    }
	}
	chi2+= ((ObsSED[i]-FOpt)/SEDErrP[i])*((ObsSED[i]-FOpt)/SEDErrP[i]);
    }
    p= TMath::Prob(chi2,9);
    Z = sqrt(2.0)*TMath::ErfcInverse(2.0*p);
    fprintf(fpt,"%13.6e  %13.6e %13.6e %13.6e\n",B0[k],chi2,p,Z);
//
    GrC = new TGraph(nc,Ec,SEDc);
    if (k==4)
    {
	GrC->SetLineColor(6);
	GrC->SetLineStyle(9);
	GrC->SetLineWidth(4);
    }
    else
    {
	GrC->SetLineColor(k+1);
	GrC->SetLineStyle(1);
	GrC->SetLineWidth(2);
    }
    GrC->Draw("L");
    }
    fclose(fp);
    fclose(fpt);
//
    c1->Update();
    c1->GetFrame()->SetFillColor(0);
    c1->GetFrame()->SetBorderMode(0);
    c1->GetFrame()->SetBorderSize(0);
    c1->SaveAs("Fig21.eps");
    c1->SaveAs("Fig21.jpg");
    if (gSystem->ProcessEvents()) break;
    c1->Modified();
}
