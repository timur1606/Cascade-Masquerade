{
#include "stdio.h"
#include "stdlib.h"
#include "math.h"

    gROOT->Reset();
    gStyle->SetOptStat(0);
    gStyle->SetPalette(1);
    gStyle->SetCanvasColor(1);
    gStyle->SetFrameFillColor(1);
    TCanvas *c1 = new TCanvas("c1","Diffuse Gamma Spectra",10,10,1100,900);
    c1->GetFrame()->SetBorderMode(-1);
    c1->SetFillColor(0);
    c1->SetLogx();
    //c1->SetLogy();
//
    const Int_t ne= 1000, nn = 100;
    int i,no = 0,nt = 0;
    double rd;
//
    double Eg12[ne],Taug12[ne];
    double Ef08[ne],Tauf08[ne];
    double Ee12[ne],Taue12[ne],Ee121[ne],Taue121[ne],Ee122[ne],Taue122[ne];
    double Ee1[ne],Taue1[ne];
    double Ek10[ne],Tauk10[ne],Tauk[ne];
//
    FILE *fp;
    h= new TH2F("","",30,3.0e-2,1.0e2,30,0.8,1.4);
    h->SetTitle("");
    h->GetXaxis()->SetTitle("E [TeV]");
    h->GetYaxis()->SetTitle("R_{#tau}");
    h->GetXaxis()->SetTitleOffset(1.4);
    h->GetYaxis()->SetTitleOffset(1.0);
    h->SetStats(kFALSE);
    h->Draw();
//
    fp= fopen("tau-0129","r");
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Ek10[i]= rd;
	fscanf(fp,"%lf",&rd); Tauk10[i]= rd;
	if(Tauk10[i]==0) {Tauk10[i] = 1.e-40;}
	Tauk[i] = 1;
    }
    fclose(fp);
//
    grk10 = new TGraph(ne,Ek10,Tauk);
    grk10->SetLineColor(2);
    grk10->SetLineWidth(2);
    grk10->Draw("L");
//
    fp= fopen("TestStripe_0129_G","r");
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Eg12[i]= rd;
	fscanf(fp,"%lf",&rd); Taug12[i]= rd/Tauk10[i];
    }
    fclose(fp);
//
    grg12 = new TGraph(ne,Eg12,Taug12);
    grg12->SetLineColor(1);
    grg12->SetLineWidth(2);
    grg12->Draw("L");
//
    fp= fopen("ELMAG-0.129-newest","r");
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Ee12[i]= rd;
	fscanf(fp,"%lf",&rd); Taue12[i]= rd/Tauk10[i];
	if(Taue12[i]>0)
	{no +=1;
	Taue121[no-1] = Taue12[i];
	Ee121[no-1] = Ee12[i];}
    }
    fclose(fp);
//
    gre12 = new TGraph(no,Ee121,Taue121);
    gre12->SetLineColor(4);
    gre12->SetLineWidth(2);
    gre12->Draw("L");
//
    fp= fopen("tau-0140","r");
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Ek10[i]= rd;
	fscanf(fp,"%lf",&rd); Tauk10[i]= rd;
	if(Tauk10[i]==0) {Tauk10[i] = 1.e-40;}
	Tauk[i] = 1;
    }
    fclose(fp);
//
    fp= fopen("TestStripe_0140_G","r");
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Ef08[i]= rd;
	fscanf(fp,"%lf",&rd); Tauf08[i]= rd/Tauk10[i];
    }
    fclose(fp);
//
    grf08 = new TGraph(ne,Ef08,Tauf08);
    grf08->SetLineColor(1);
    grf08->SetLineStyle(9);
    grf08->SetLineWidth(2);
    grf08->Draw("L");
//
    fp= fopen("ELMAG-0.140-newest","r");
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Ee1[i]= rd;
	fscanf(fp,"%lf",&rd); Taue1[i]= rd/Tauk10[i];
	if(Taue1[i]>0)
	{nt +=1;
	Taue122[nt-1] = Taue1[i];
	Ee122[nt-1] = Ee1[i];}
    }
    fclose(fp);
//
    gre13 = new TGraph(nt,Ee122,Taue122);
    gre13->SetLineColor(4);
    gre13->SetLineStyle(9);
    gre13->SetLineWidth(2);
    gre13->Draw("L");
//
    c1->Update();
    c1->GetFrame()->SetFillColor(0);
    c1->GetFrame()->SetBorderMode(0);
    c1->GetFrame()->SetBorderSize(0);
    c1->SaveAs("FigC1e.eps");
    c1->SaveAs("FigC1e.jpg");
    if (gSystem->ProcessEvents()) break;
    c1->Modified();
}
