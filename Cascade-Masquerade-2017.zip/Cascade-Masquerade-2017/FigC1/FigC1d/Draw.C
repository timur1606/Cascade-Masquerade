{
#include "stdio.h"
#include "stdlib.h"
#include "math.h"

    gROOT->Reset();
    gStyle->SetOptStat(0);
    gStyle->SetPalette(1);
    gStyle->SetCanvasColor(1);
    gStyle->SetFrameFillColor(1);
    TCanvas *c1 = new TCanvas("c1","Diffuse Gamma Spectra",10,10,1100,900);
    c1->GetFrame()->SetBorderMode(-1);
    c1->SetFillColor(0);
    c1->SetLogx();
    c1->SetLogy();
//
    const Int_t ne= 1000, nn = 100;
    int i,no = 0;
    double rd;
//
    double Eg12[ne],Taug12[ne];
    double Ef08[ne],Tauf08[ne];
    double Ee12[ne],Taue12[ne],Ee121[ne],Taue121[ne];
    double Ek10[ne],Tauk10[ne];
//
    FILE *fp;
    h= new TH2F("","",30,3.0e-2,1.0e2,30,1.0e-2,7.0e2);
    h->SetTitle("");
    h->GetXaxis()->SetTitle("E [TeV]");
    h->GetYaxis()->SetTitle("#tau");
    h->GetXaxis()->SetTitleOffset(1.4);
    h->GetYaxis()->SetTitleOffset(1.0);
    h->SetStats(kFALSE);
    h->Draw();
//
    fp= fopen("TestStripe_0287_G","r");
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Eg12[i]= rd;
	fscanf(fp,"%lf",&rd); Taug12[i]= rd;
    }
    fclose(fp);
//
    grg12 = new TGraph(ne,Eg12,Taug12);
    grg12->SetLineColor(1);
    grg12->SetLineWidth(2);
    grg12->Draw("L");
//
    fp= fopen("TestStripe_0287_F","r");
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Ef08[i]= rd;
	fscanf(fp,"%lf",&rd); Tauf08[i]= rd;
    }
    fclose(fp);
//
    grf08 = new TGraph(ne,Ef08,Tauf08);
    grf08->SetLineColor(3);
    grf08->SetLineWidth(2);
    grf08->Draw("L");
//
    fp= fopen("ELMAG-0.287-newest","r");
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Ee12[i]= rd;
	fscanf(fp,"%lf",&rd); Taue12[i]= rd;
	if(Taue12[i]>0)
	{no +=1;
	Taue121[no-1] = Taue12[i];
	Ee121[no-1] = Ee12[i];}
    }
    fclose(fp);
//
    gre12 = new TGraph(no-1,Ee121,Taue121);
    gre12->SetLineColor(4);
    gre12->SetLineWidth(2);
    gre12->Draw("L");
//
    fp= fopen("tau-0287","r");
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Ek10[i]= rd;
	fscanf(fp,"%lf",&rd); Tauk10[i]= rd;
    }
    fclose(fp);
//
    grk10 = new TGraph(ne,Ek10,Tauk10);
    grk10->SetLineColor(2);
    grk10->SetLineWidth(2);
    grk10->Draw("L");
//
    c1->Update();
    c1->GetFrame()->SetFillColor(0);
    c1->GetFrame()->SetBorderMode(0);
    c1->GetFrame()->SetBorderSize(0);
    c1->SaveAs("FigC1d.eps");
    c1->SaveAs("FigC1d.jpg");
    if (gSystem->ProcessEvents()) break;
    c1->Modified();
}
