{
#include "stdio.h"
#include "stdlib.h"
#include "math.h"

    gROOT->Reset();
    gStyle->SetOptStat(0);
    gStyle->SetPalette(1);
    gStyle->SetCanvasColor(1);
    gStyle->SetFrameFillColor(1);
    TCanvas *c1 = new TCanvas("c1","Diffuse Gamma Spectra",10,10,1100,900);
    c1->GetFrame()->SetBorderMode(-1);
    c1->SetFillColor(0);
    c1->SetLogx();
    c1->SetLogy();
//
    const Int_t ne= 201;
    const Int_t nb= 5;
    int i,j;
    double rd;
    double E1[ne],KMod1[ne];
    double E2[ne],KMod2[ne];
    FILE *fp;
//
    fp= fopen("ModFactor","r");
    if (fp==NULL)
    {
	printf("Error: input file1 not found!\n");
	return;
    }
//
    h= new TH2F("","",30,1.0e18,1.0e20,30,0.5,1.0e4);
    h->SetTitle("");
    h->GetXaxis()->SetTitle("E [eV]");
    h->GetYaxis()->SetTitle("K_{M}");
    h->GetXaxis()->SetTitleOffset(1.4);
    h->GetYaxis()->SetTitleOffset(1.2);
    h->SetStats(kFALSE);
    h->Draw();
//
    for (j=0; j<201; j++)
    {
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); E1[i]= rd;
	fscanf(fp,"%lf",&rd);
	fscanf(fp,"%lf",&rd);
	fscanf(fp,"%lf",&rd); KMod1[i]= rd;
    }
//
    Gr1 = new TGraph(ne,E1,KMod1);
    if (j==4)	Gr1->SetLineColor(6);
    else	Gr1->SetLineColor(j+1);
    Gr1->SetLineWidth(2);
    Gr1->Draw("L");
    }
    fclose(fp);
//
    c1->Update();
    c1->GetFrame()->SetFillColor(0);
    c1->GetFrame()->SetBorderMode(0);
    c1->GetFrame()->SetBorderSize(0);
    c1->SaveAs("Fig20.eps");
    c1->SaveAs("Fig20.jpg");
    if (gSystem->ProcessEvents()) break;
    c1->Modified();
}
