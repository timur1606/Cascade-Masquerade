{
#include "stdio.h"
#include "stdlib.h"
#include "math.h"
// 1. Init
    gROOT->Reset();
    gStyle->SetOptStat(0);
    gStyle->SetPalette(1);
    gStyle->SetCanvasColor(1);
    gStyle->SetFrameFillColor(1);
    TCanvas *c1 = new TCanvas("c1","Exp. and Model Gamma Spectra",10,10,1100,900);
    c1->GetFrame()->SetBorderMode(-1);
    c1->SetFillColor(0);
    c1->SetLogx();
// 2. Define constants
    const Int_t ne= 1000;
    const Int_t nm= 50;
    const Int_t PrintFlag= 0;
// 3. Define variables
    int i,j,m,m2,ri;
    double rd;
//
    double lx[ne],ly[ne];
    Double_t Ea[ne],SEDa[ne];
    Double_t Ec[ne],SEDc[ne];
    Double_t E[ne],Ratio[ne];
    Double_t Em[nm],Rm[nm];
    FILE *fp;
//
    fp= fopen("AOM","r");
    fscanf(fp,"%d",&ri);
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Ea[i]= rd;
	fscanf(fp,"%lf",&rd); SEDa[i]= rd;
    }
    fclose(fp);
//
    fp= fopen("EMC","r");
    fscanf(fp,"%d",&ri);
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Ec[i]= rd;
	fscanf(fp,"%lf",&rd); SEDc[i]= rd;
    }
    fclose(fp);
    for (i=0; i<ne; i++)
    {
	E[i]= Ec[i];
	Ratio[i]= 1.0;
    }
    for (i=0; i<ne; i++)
    {
	if ((fabs(SEDa[i])>1.0e-40)&&(fabs(SEDc[i])>1.0e-40))
	    Ratio[i]= SEDc[i]/SEDa[i];
    }
//
    m= 20;
    m2= (int) (0.5*m);
    for (i=0; i<nm; i++)
    {
	Rm[i]= 0.0;
	if (m*i+m2<ne)
	Em[i]= E[m*i+m2];
    }
    for (i=0; i<nm; i++)
    {
	for (j=0; j<m; j++)
	{
	    if (m*i+j<ne)
		Rm[i]+= Ratio[m*i+j]/((double)(m));
	}
    }
// 7. Draw histogram to zoom graphs
    h= new TH2F("","",30,0.2,13.0,30,0.7,4.0);
    h->GetXaxis()->SetTitle("E [TeV]");
    h->GetXaxis()->SetTitleOffset(1.4);
    h->GetYaxis()->SetTitle("K_{B}");
    h->SetStats(kFALSE);
    h->Draw();
//
    Gr = new TGraph(ne,E,Ratio);
    Gr->SetLineColor(2);		//for line
    Gr->SetLineWidth(2);		//mode
    Gr->SetTitle("");
    Gr->Draw("L");
//
    Grm = new TGraph(nm,Em,Rm);
    Grm->SetMarkerStyle(8);
    Grm->SetMarkerColor(4);
    Grm->SetMarkerSize(1.5);
    Grm->SetTitle("");
    Grm->Draw("P");
//
    for (i=0; i<ne; i++)
    {
	lx[i]= 0.56+1.5e-4*i;
	ly[i]= 0.81;
    }
//
    c1->Update();
    c1->GetFrame()->SetFillColor(0);
    c1->GetFrame()->SetBorderMode(0);
    c1->GetFrame()->SetBorderSize(0);
    c1->SaveAs("Fig13.eps");
    c1->SaveAs("Fig13.jpg");
    if (gSystem->ProcessEvents()) break;
    c1->Modified();
}
