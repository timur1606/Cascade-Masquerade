//ПОСТРОЕНИЕ ГРАФИКОВ

int Draw()
{
	const int nbin;
	double tmpd;
	int tmpi;
	double *E_exp, *S_exp, *S_stat_m, *S_stat_p;

	const int nbin1 = 50;
	const int nbin2 = 41;
	const int nbin3 = 40;
	const int nbin4 = 43;
	const int nbin5 = 100;
	Double_t E1[nbin1],S1[nbin1],E2[nbin2],S2[nbin2],E3[nbin3],S3[nbin3],E4[nbin4],S4[nbin4],E5[nbin5],S5[nbin5];

    //ЧТЕНИЕ ЭКСПЕРИМЕНТАЛЬНОГО СПЕКТРА (1) ///////////////////////////////////////////////////////////////////
    FILE *fp = fopen("014full","r");
    if (fp == NULL) cout << "wrong filename in input file" << endl;
    fscanf(fp,"%d %le",&nbin, &tmpd);
    E_exp = new double[nbin];
    S_exp = new double[nbin];
    S_stat_m = new double[nbin];
    S_stat_p = new double[nbin];
    for (int i = 0; i < nbin; i++)
    {
		fscanf(fp, "%d", &tmpd); //
        fscanf(fp, "%le", &E_exp[i]); //середина бина, ТэВ
        fscanf(fp, "%le", &tmpd); //начало бина, ТэВ
        fscanf(fp, "%le", &tmpd); //конец бина, ТэВ
        fscanf(fp, "%le", &S_exp[i]); // dN/dE
        S_exp[i] *= E_exp[i]*E_exp[i]; // E^2*dN/dE
        fscanf(fp, "%le", &S_stat_p[i]); //статистическая погрешность +
        fscanf(fp, "%le", &S_stat_m[i]); //статистическая погрешность -
        S_stat_p[i] *= E_exp[i]*E_exp[i];
        S_stat_m[i] *= -E_exp[i]*E_exp[i];
        for (int j = 0; j < 2; j++)
            fscanf(fp, "%le", &tmpd); //оставшиеся погрешности (2 сист)
    }
    fclose(fp);

    fp = fopen("outspec-kh","r");
    for (int i = 0; i < nbin1; i++)
		fscanf(fp,"%le %le",&E1[i],&S1[i]);
	fclose(fp);

    fp = fopen("outspec-kl","r");
    for (int i = 0; i < nbin2; i++)
		fscanf(fp,"%le %le",&E2[i],&S2[i]);
	fclose(fp);

    fp = fopen("outspec-mg","r");
    for (int i = 0; i < nbin3; i++)
		fscanf(fp,"%le %le",&E3[i],&S3[i]);
	fclose(fp);

    fp = fopen("outspec-mr","r");
    for (int i = 0; i < nbin4; i++)
		fscanf(fp,"%le %le",&E4[i],&S4[i]);
	fclose(fp);

	fp = fopen("outspec-pwl","r");
    for (int i = 0; i < nbin5; i++)
		fscanf(fp,"%le %le",&E5[i],&S5[i]);
	fclose(fp);

//*/
    //Init ROOT:
    gStyle->SetOptStat(0);
    gStyle->SetPalette(1);
    gStyle->SetCanvasColor(1);
    gStyle->SetFrameFillColor(1);
    TCanvas *c1 = new TCanvas("c1","BLACK:kh,MAGENTA:kl,GREEN:mg,BLUE:mr;BLACK_BIG=1e15zc0",0,0,1200,1000);
    c1->GetFrame()->SetBorderMode(-1);
    c1->SetFillColor(0);
    c1->SetLogx();
    c1->SetLogy();

    //Draw histogram to zoom graphs:
    h= new TH2F("","",30,1e-1,100,30,2e-14,3e-12); //log
    h->GetXaxis()->SetTitle("E [TeV]");
    h->GetYaxis()->SetTitle("SED [TeVcm^{-2}s^{-1}]");
    h->GetXaxis()->SetTitleOffset(1.4);
    h->GetYaxis()->SetTitleOffset(1.5);
    h->SetStats(kFALSE);
    h->Draw();


    //DRAW:
//draw small symbols (!!!!!!!!) and statistical uncertainties
    GrSexp = new TGraphAsymmErrors(nbin,E_exp,S_exp,NULL,NULL,S_stat_m,S_stat_p);
    GrSexp->SetMarkerColor(1);
    GrSexp->SetMarkerStyle(8);
    GrSexp->SetMarkerSize(0.5);
    GrSexp->SetLineColor(2);
    GrSexp->SetLineWidth(2);
    GrSexp->Draw("P");
//draw VERITAS and HESS separately (!!!!!!!!)
    const Int_t nbin20= 9;
    const Int_t nbin30= 8;
    int s2,s3;
    Double_t E20[100];
    Double_t S20[100];
    Double_t E30[100];
    Double_t S30[100];
    s2= 0;
    s3= 0;
    for (i=0; i<nbin; i++)
    {
	if ((i==0)||(i==1)||(i==3)||(i==5)||(i==7)||(i==9)||(i==11)||(i==13)||(i==15))
	{
	    E20[s2]= E_exp[i];
	    S20[s2]= S_exp[i];
	    s2++;
	}
    }
    for (i=0; i<nbin; i++)
    {
	if ((i==2)||(i==4)||(i==6)||(i==8)||(i==10)||(i==12)||(i==14)||(i==16))
	{
	    E30[s3]= E_exp[i];
	    S30[s3]= S_exp[i];
	    s3++;
	}
    }
//    nbin2= s2;
//    nbin3= s3;
    Gr2 = new TGraph(nbin20,E20,S20);
    Gr2->SetMarkerColor(2);
    Gr2->SetMarkerStyle(8);
    Gr2->SetMarkerSize(1.5);
    Gr2->Draw("P");
//
    Gr3= new TGraph(nbin30,E30,S30);
    Gr3->SetMarkerColor(2);
    Gr3->SetMarkerStyle(22);
    Gr3->SetMarkerSize(1.5);
    Gr3->Draw("P");
//



    Gr1 = new TGraph(nbin1,E1,S1); //ZC = 0 => BLACK
    Gr1->SetLineColor(1);
    Gr1->SetLineWidth(2);
    Gr1->SetLineStyle(1);
    Gr1->Draw("L");

    Gr2 = new TGraph(nbin2,E2,S2); //ZC = 0.02 => MAGENTA
    Gr2->SetLineColor(6);
    Gr2->SetLineWidth(2);
    Gr2->SetLineStyle(1);
    Gr2->Draw("L");

    Gr3 = new TGraph(nbin3,E3,S3); //ZC = 0.05 => GREEN
    Gr3->SetLineColor(3);
    Gr3->SetLineWidth(3);
    Gr3->SetLineStyle(1);
    Gr3->Draw("L");

    Gr4 = new TGraph(nbin4,E4,S4); //ZC = 0.1 => BLUE
    Gr4->SetLineColor(4);
    Gr4->SetLineWidth(2);
    Gr4->SetLineStyle(1);
    Gr4->Draw("L");

    Gr5 = new TGraph(nbin5,E5,S5); //PWL = BLACK BIG
    Gr5->SetLineColor(1);
    Gr5->SetLineWidth(4);
    Gr5->SetLineStyle(7);
    Gr5->Draw("L");
    //*/

    c1->Update();
    c1->GetFrame()->SetFillColor(0);
    c1->GetFrame()->SetBorderMode(0);
    c1->GetFrame()->SetBorderSize(0);
    c1->SaveAs("FigD2.eps");
    c1->SaveAs("FigD2.jpg");
    if (gSystem->ProcessEvents()) break;
    c1->Modified();

}
