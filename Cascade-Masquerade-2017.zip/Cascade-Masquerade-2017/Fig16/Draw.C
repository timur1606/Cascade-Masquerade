{
#include "stdio.h"
#include "stdlib.h"
#include "math.h"

    gROOT->Reset();
    gStyle->SetOptStat(0);
    gStyle->SetPalette(1);
    gStyle->SetCanvasColor(1);
    gStyle->SetFrameFillColor(1);
    TCanvas *c1 = new TCanvas("c1","Diffuse Gamma Spectra",10,10,1100,900);
    c1->GetFrame()->SetBorderMode(-1);
    c1->SetFillColor(0);
    c1->SetLogx();
//
    const Int_t ne= 1000;
    const Double_t smalld= 1.0e-40;
    int i,ri;
    int ns,f,n2;
    double rd;
//
    double EAbs[ne],SEDAbs[ne];
    double EEMC[ne],SEDEMC[ne];
    double ER[ne],Ratio0[ne],Ratio[ne];
    double xl[ne],yl[ne];
    FILE *fp;
//
    h= new TH2F("","",30,0.1,17.0,30,0.5,2.5);
    h->SetTitle("");
    h->GetXaxis()->SetTitle("E [TeV]");
    h->GetYaxis()->SetTitle("K_{B}");
    h->GetXaxis()->SetTitleOffset(1.4);
    h->GetYaxis()->SetTitleOffset(1.4);
    h->SetStats(kFALSE);
    h->Draw();
//
    fp= fopen("Absorption-ELMAG","r");
    fscanf(fp,"%d",&ri);
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); EAbs[i]= rd;
	fscanf(fp,"%lf",&rd); SEDAbs[i]= rd;
    }
    fclose(fp);
//
    fp= fopen("EMCascade-V1.0","r");
    fscanf(fp,"%d",&ri);
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); EEMC[i]= rd;
	fscanf(fp,"%lf",&rd); SEDEMC[i]= rd;
    }
    fclose(fp);
//
    for (i=0; i<ne; i++)
    {
	Ratio0[i]= 0.0;
	Ratio[i]= 0.0;
    }
    for (i=0; i<ne; i++)
    {
	if ((fabs(SEDAbs[i])>smalld)&&(fabs(SEDEMC[i])>smalld))
	    Ratio0[i]= SEDEMC[i]/SEDAbs[i];
    }
    ns= 0;
    f= 0;
    for (i=0; i<ne; i++)
    {
	if ((fabs(Ratio0[i])>smalld)&&(f==0))
	{
	    ns= i;
	    f= 1;
	}
    }
    printf("ns= %4d\n",ns);
    for (i=0; i<ne; i++)
    {
	n2= i+ns;
	if (n2<ne)
	{
	    ER[i]= EAbs[n2];
	    Ratio[i]= Ratio0[n2];
	}
    }
//
    gr = new TGraph(ne,ER,Ratio);
    gr->SetLineColor(1);
    gr->SetLineWidth(2);
    gr->Draw("L");
//
    fp= fopen("EMCascade-V0.6","r");
    fscanf(fp,"%d",&ri);
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); EEMC[i]= rd;
	fscanf(fp,"%lf",&rd); SEDEMC[i]= rd;
    }
    fclose(fp);
//
    for (i=0; i<ne; i++)
    {
	Ratio0[i]= 0.0;
	Ratio[i]= 0.0;
    }
    for (i=0; i<ne; i++)
    {
	if ((fabs(SEDAbs[i])>smalld)&&(fabs(SEDEMC[i])>smalld))
	    Ratio0[i]= SEDEMC[i]/SEDAbs[i];
    }
    ns= 0;
    f= 0;
    for (i=0; i<ne; i++)
    {
	if ((fabs(Ratio0[i])>smalld)&&(f==0))
	{
	    ns= i;
	    f= 1;
	}
    }
    printf("ns= %4d\n",ns);
    for (i=0; i<ne; i++)
    {
	n2= i+ns;
	if (n2<ne)
	{
	    ER[i]= EAbs[n2];
	    Ratio[i]= Ratio0[n2];
	}
    }
//
    gr = new TGraph(ne,ER,Ratio);
    gr->SetLineColor(3);
    gr->SetLineWidth(2);
    gr->Draw("L");
//
    fp= fopen("EMCascade-V0.4","r");
    fscanf(fp,"%d",&ri);
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); EEMC[i]= rd;
	fscanf(fp,"%lf",&rd); SEDEMC[i]= rd;
    }
    fclose(fp);
//
    for (i=0; i<ne; i++)
    {
	Ratio0[i]= 0.0;
	Ratio[i]= 0.0;
    }
    for (i=0; i<ne; i++)
    {
	if ((fabs(SEDAbs[i])>smalld)&&(fabs(SEDEMC[i])>smalld))
	    Ratio0[i]= SEDEMC[i]/SEDAbs[i];
    }
    ns= 0;
    f= 0;
    for (i=0; i<ne; i++)
    {
	if ((fabs(Ratio0[i])>smalld)&&(f==0))
	{
	    ns= i;
	    f= 1;
	}
    }
    printf("ns= %4d\n",ns);
    for (i=0; i<ne; i++)
    {
	n2= i+ns;
	if (n2<ne)
	{
	    ER[i]= EAbs[n2];
	    Ratio[i]= Ratio0[n2];
	}
    }
//
    gr = new TGraph(ne,ER,Ratio);
    gr->SetLineColor(4);
    gr->SetLineWidth(2);
    gr->Draw("L");
//
    fp= fopen("EMCascade-V0.3","r");
    fscanf(fp,"%d",&ri);
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); EEMC[i]= rd;
	fscanf(fp,"%lf",&rd); SEDEMC[i]= rd;
    }
    fclose(fp);
//
    for (i=0; i<ne; i++)
    {
	Ratio0[i]= 0.0;
	Ratio[i]= 0.0;
    }
    for (i=0; i<ne; i++)
    {
	if ((fabs(SEDAbs[i])>smalld)&&(fabs(SEDEMC[i])>smalld))
	    Ratio0[i]= SEDEMC[i]/SEDAbs[i];
    }
    ns= 0;
    f= 0;
    for (i=0; i<ne; i++)
    {
	if ((fabs(Ratio0[i])>smalld)&&(f==0))
	{
	    ns= i;
	    f= 1;
	}
    }
    printf("ns= %4d\n",ns);
    for (i=0; i<ne; i++)
    {
	n2= i+ns;
	if (n2<ne)
	{
	    ER[i]= EAbs[n2];
	    Ratio[i]= Ratio0[n2];
	}
    }
//
    gr = new TGraph(ne,ER,Ratio);
    gr->SetLineColor(7);
    gr->SetLineWidth(2);
    gr->Draw("L");
//
    fp= fopen("EMCascade-V0.2","r");
    fscanf(fp,"%d",&ri);
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); EEMC[i]= rd;
	fscanf(fp,"%lf",&rd); SEDEMC[i]= rd;
    }
    fclose(fp);
//
    for (i=0; i<ne; i++)
    {
	Ratio0[i]= 0.0;
	Ratio[i]= 0.0;
    }
    for (i=0; i<ne; i++)
    {
	if ((fabs(SEDAbs[i])>smalld)&&(fabs(SEDEMC[i])>smalld))
	    Ratio0[i]= SEDEMC[i]/SEDAbs[i];
    }
    ns= 0;
    f= 0;
    for (i=0; i<ne; i++)
    {
	if ((fabs(Ratio0[i])>smalld)&&(f==0))
	{
	    ns= i;
	    f= 1;
	}
    }
    printf("ns= %4d\n",ns);
    for (i=0; i<ne; i++)
    {
	n2= i+ns;
	if (n2<ne)
	{
	    ER[i]= EAbs[n2];
	    Ratio[i]= Ratio0[n2];
	}
    }
//
    gr = new TGraph(ne,ER,Ratio);
    gr->SetLineColor(6);
    gr->SetLineWidth(2);
    gr->Draw("L");
//KD10
//tau= 1 -> E= 0.723 TeV
//tau= 2 -> E= 3.311 TeV
    for (i=0; i<ne; i++)
    {
	xl[i]= 0.723;
	yl[i]= 1.0e-2*i;
    }
    grl = new TGraph(ne,xl,yl);
    grl->SetLineColor(2);
    grl->SetLineWidth(2);
    grl->SetLineStyle(9);
    grl->Draw("L");
//
    for (i=0; i<ne; i++)
    {
	xl[i]= 3.311;
	yl[i]= 1.0e-2*i;
    }
    grl = new TGraph(ne,xl,yl);
    grl->SetLineColor(2);
    grl->SetLineWidth(2);
    grl->Draw("L");
//G12
//tau= 1 -> E= 0.596 TeV
//tau= 2 -> E= 1.679 TeV
    for (i=0; i<ne; i++)
    {
	xl[i]= 0.596;
	yl[i]= 1.0e-2*i;
    }
    grl = new TGraph(ne,xl,yl);
    grl->SetLineColor(1);
    grl->SetLineWidth(2);
    grl->SetLineStyle(9);
    grl->Draw("L");
//
    for (i=0; i<ne; i++)
    {
	xl[i]= 1.679;
	yl[i]= 1.0e-2*i;
    }
    grl = new TGraph(ne,xl,yl);
    grl->SetLineColor(1);
    grl->SetLineWidth(2);
    grl->Draw("L");
//F08
//tau= 1 -> E= 0.660 TeV
//tau= 2 -> E= 1.972 TeV
    for (i=0; i<ne; i++)
    {
	xl[i]= 0.660;
	yl[i]= 1.0e-2*i;
    }
    grl = new TGraph(ne,xl,yl);
    grl->SetLineColor(3);
    grl->SetLineWidth(2);
    grl->SetLineStyle(9);
    grl->Draw("L");
//
    for (i=0; i<ne; i++)
    {
	xl[i]= 1.972;
	yl[i]= 1.0e-2*i;
    }
    grl = new TGraph(ne,xl,yl);
    grl->SetLineColor(3);
    grl->SetLineWidth(2);
    grl->Draw("L");
//ELMAG option2 (= KD10 in ELMAG)
//tau= 1 -> E= 0.645 TeV
//tau= 2 -> E= 1.670 TeV
    for (i=0; i<ne; i++)
    {
	xl[i]= 0.645;
	yl[i]= 1.0e-2*i;
    }
    grl = new TGraph(ne,xl,yl);
    grl->SetLineColor(4);
    grl->SetLineWidth(2);
    grl->SetLineStyle(9);
    grl->Draw("L");
//
    for (i=0; i<ne; i++)
    {
	xl[i]= 1.670;
	yl[i]= 1.0e-2*i;
    }
    grl = new TGraph(ne,xl,yl);
    grl->SetLineColor(4);
    grl->SetLineWidth(2);
    grl->Draw("L");

//
    c1->Update();
    c1->GetFrame()->SetFillColor(0);
    c1->GetFrame()->SetBorderMode(0);
    c1->GetFrame()->SetBorderSize(0);
    c1->SaveAs("Fig16.eps");
    c1->SaveAs("Fig16.jpg");
    if (gSystem->ProcessEvents()) break;
    c1->Modified();
}
