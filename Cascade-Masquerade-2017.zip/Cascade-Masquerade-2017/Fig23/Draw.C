{
#include "stdio.h"
#include "stdlib.h"
#include "math.h"

    gROOT->Reset();
    gStyle->SetOptStat(0);
    gStyle->SetPalette(1);
    gStyle->SetCanvasColor(1);
    gStyle->SetFrameFillColor(1);
    TCanvas *c1 = new TCanvas("c1","Interpolated Acceptance Table",0,0,1000,1000);
    c1->GetFrame()->SetBorderMode(-1);
    c1->SetFillColor(0);
    const Int_t nz= 201;
    const Int_t ne= 201;
    int i,j;
    double rd,kn,eps;
    double E[ne],z[nz];
    double S[nz][ne];
    FILE *fp;
//1. read data
    eps= 1.0e-5;
    fp= fopen("Table-Gamma-30","r");
    for (i=0; i<nz; i++)
    {
	fscanf(fp,"%lf",&rd);
	z[i]= rd;
    }
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); E[i]= rd;
	for (j=0; j<nz; j++)
	{
	    fscanf(fp,"%lf",&rd);
	    S[j][i]= rd;
	    if (S[j][i]>10.0) S[j][i]=10.0;
	}
    }
    fclose(fp);
//3. draw 2D hist
    h= new TH2F("h","h2",nz,0.0,0.140,ne-1,-9.0,-5.0);
    for (i=0; i<nz; i++)
    {
        for (j=0; j<ne; j++)
	    h->Fill(0.14*((double)(i))/201.0+eps,-9+0.02*j+eps,S[i][j]); //VALUE(x), VALUE(y)
    }
//
    h->SetContour(10000);
    h->SetTitle("");
    h->GetXaxis()->SetTitle("z_{c}");
    h->GetYaxis()->SetTitle("lg(B_{0} [G])");
    h->GetXaxis()->SetTitleOffset(1.2);
    h->GetYaxis()->SetTitleOffset(1.4);
    h->Draw("COLZ");
//4.save graph
    c1->Update();
    c1->GetFrame()->SetFillColor(0);
    c1->GetFrame()->SetBorderMode(0);
    c1->GetFrame()->SetBorderSize(0);
    c1->SaveAs("Fig23.eps");
    c1->SaveAs("Fig23.jpg");
    if (gSystem->ProcessEvents()) break;
    c1->Modified();
}
