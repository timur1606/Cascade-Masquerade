{
#include "stdio.h"
#include "stdlib.h"
#include "math.h"

    gROOT->Reset();
    gStyle->SetOptStat(0);
    gStyle->SetPalette(1);
    gStyle->SetCanvasColor(1);
    gStyle->SetFrameFillColor(1);
    TCanvas *c1 = new TCanvas("c1","Diffuse Gamma Spectra",10,10,1100,900);
    c1->GetFrame()->SetBorderMode(-1);
    c1->SetFillColor(0);
    c1->SetLogx();
    c1->SetLogy();
//
    const Int_t ne= 100;
    const Int_t PrintFlag= 0;
    int i,NExp;
    double KE,K1,K2,K3,rd;
    double E1[ne],SED1[ne];
    double E2[ne],SED2[ne];
    double E3[ne],SED3[ne];
    double E4[ne],SED4[ne];
    double E5[ne],SED5[ne];
    double E6[ne],SED6[ne];
//
    double Eh1[ne],SEDh1[ne];
    double Eh2[ne],SEDh2[ne];
    double Eh3[ne],SEDh3[ne];
    double Eh4[ne],SEDh4[ne];
    double Eh5[ne],SEDh5[ne];
    double Eh6[ne],SEDh6[ne];
//
    double Eg[ne],SEDg[ne];
//
    FILE *fp;
//
    fp= fopen("Universal-Z-0186-0000","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
    KE= 1.0e-12;
    K1= 1.0;
    K2= 8.0e-33;
    K3= 1.0;
//
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
//
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); E1[i]= KE*rd;
	fscanf(fp,"%lf",&rd); SED1[i]= K1*K2*K3*rd/1.301429;
    }
    fclose(fp);
//
    for (i=0; i<ne; i++)
	printf("%13.6e %13.6e\n",E1[i],SED1[i]);
//
    fp= fopen("FullHybrid-Z-0186-0000","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
//
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
//
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Eh1[i]= KE*rd;
	fscanf(fp,"%lf",&rd); SEDh1[i]= 1.0e-3*K1*K2*K3*rd/1.301429;
    }
    fclose(fp);
//
    fp= fopen("Universal-Z-0186-0020","r");
    if (fp==NULL)
    {
	printf("Error: input file2 not found!\n");
	return;
    }
//
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
//
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); E2[i]= KE*rd;
	fscanf(fp,"%lf",&rd); SED2[i]= K1*K2*K3*rd/1.301429;
    }
    fclose(fp);
//
    fp= fopen("FullHybrid-Z-0186-0020","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
//
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
//
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Eh2[i]= KE*rd;
	fscanf(fp,"%lf",&rd); SEDh2[i]= 1.0e-3*K1*K2*K3*rd/1.301429;
    }
    fclose(fp);
//
    fp= fopen("Universal-Z-0186-0050","r");
    if (fp==NULL)
    {
	printf("Error: input file3 not found!\n");
	return;
    }
    K1= 1.1;
//
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
//
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); E3[i]= KE*rd;
	fscanf(fp,"%lf",&rd); SED3[i]= K1*K2*K3*rd/1.301429;
    }
    fclose(fp);
//
    fp= fopen("FullHybrid-Z-0186-0050","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
//
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
//
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Eh3[i]= KE*rd;
	fscanf(fp,"%lf",&rd); SEDh3[i]= 1.0e-3*K1*K2*K3*rd/1.301429;
    }
    fclose(fp);
//
    fp= fopen("Universal-Z-0186-0100","r");
    if (fp==NULL)
    {
	printf("Error: input file4 not found!\n");
	return;
    }
    K1= 1.45;
//
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
//
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); E4[i]= KE*rd;
	fscanf(fp,"%lf",&rd); SED4[i]= K1*K2*K3*rd/1.301429;
    }
    fclose(fp);
//
    fp= fopen("FullHybrid-Z-0186-0100","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
//
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
//
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Eh4[i]= KE*rd;
	fscanf(fp,"%lf",&rd); SEDh4[i]= 1.0e-3*K1*K2*K3*rd/1.301429;
    }
    fclose(fp);
//
    fp= fopen("Universal-Z-0186-0150","r");
    if (fp==NULL)
    {
	printf("Error: input file4 not found!\n");
	return;
    }
    K1= 2.95;
//
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
//
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); E5[i]= KE*rd;
	fscanf(fp,"%lf",&rd); SED5[i]= K1*K2*K3*rd/1.301429;
    }
    fclose(fp);
//
    fp= fopen("FullHybrid-Z-0186-0150","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
//
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
//
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Eh5[i]= KE*rd;
	fscanf(fp,"%lf",&rd); SEDh5[i]= 1.0e-3*K1*K2*K3*rd/1.301429;
    }
    fclose(fp);
//
    fp= fopen("Universal-Z-0186-0180","r");
    if (fp==NULL)
    {
	printf("Error: input file4 not found!\n");
	return;
    }
    K1= 2.95*5.4;
//
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
//
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); E6[i]= KE*rd;
	fscanf(fp,"%lf",&rd); SED6[i]= K1*K2*K3*rd/1.301429;
    }
    fclose(fp);
//
    fp= fopen("FullHybrid-Z-0186-0180","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
//
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
//
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Eh6[i]= KE*rd;
	fscanf(fp,"%lf",&rd); SEDh6[i]= 1.0e-3*K1*K2*K3*rd/1.301429;
    }
    fclose(fp);
//
    fp= fopen("Gamma-Z-0186-1PeV","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
    K2= 3.8e-19/5.4;
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Eg[i]= KE*rd;
	fscanf(fp,"%lf",&rd); SEDg[i]= K1*K2*K3*rd/1.301429;
    }
    fclose(fp);
// 7. Draw histogram to zoom graphs
    h= new TH2F("","",30,0.01,100.0,30,1.0e-2,2.0);
    h->GetXaxis()->SetTitle("E [TeV]");
    h->GetYaxis()->SetTitle("SED [arb. units]");
    h->GetXaxis()->SetTitleOffset(1.2);
    h->GetYaxis()->SetTitleOffset(0.8);
    h->SetStats(kFALSE);
    h->Draw();
//
    gr1 = new TGraph(ne,E1,SED1);
    gr1->SetLineColor(1);
    gr1->SetLineWidth(2);
    gr1->Draw("L");
//
    grh1 = new TGraph(ne,Eh1,SEDh1);
    grh1->SetMarkerColor(1);
    grh1->SetMarkerSize(1.0);
    grh1->SetMarkerStyle(8);
    grh1->Draw("P");
//
    gr2 = new TGraph(ne,E2,SED2);
    gr2->SetLineColor(2);		//for line
    gr2->SetLineWidth(2);		//mode
    gr2->Draw("L");
//
    grh2 = new TGraph(ne,Eh2,SEDh2);
    grh2->SetMarkerColor(2);
    grh2->SetMarkerSize(1.0);
    grh2->SetMarkerStyle(8);
    grh2->Draw("P");
//
    gr3 = new TGraph(ne,E3,SED3);
    gr3->SetLineColor(3);		//for line
    gr3->SetLineWidth(2);		//mode
    gr3->Draw("L");
//
    grh3 = new TGraph(ne,Eh3,SEDh3);
    grh3->SetMarkerColor(3);
    grh3->SetMarkerSize(1.0);
    grh3->SetMarkerStyle(8);
    grh3->Draw("P");
//
    gr4 = new TGraph(ne,E4,SED4);
    gr4->SetLineColor(4);		//for line
    gr4->SetLineWidth(2);		//mode
    gr4->Draw("L");
//
    grh4 = new TGraph(ne,Eh4,SEDh4);
    grh4->SetMarkerColor(4);
    grh4->SetMarkerSize(1.0);
    grh4->SetMarkerStyle(8);
    grh4->Draw("P");
//
    gr5 = new TGraph(ne,E5,SED5);
    gr5->SetLineColor(7);		//for line
    gr5->SetLineWidth(2);		//mode
    gr5->Draw("L");
//
    grh5 = new TGraph(ne,Eh5,SEDh5);
    grh5->SetMarkerColor(7);
    grh5->SetMarkerSize(1.0);
    grh5->SetMarkerStyle(8);
    grh5->Draw("P");
//
    grg = new TGraph(ne,Eg,SEDg);
    grg->SetLineColor(1);
    grg->SetLineWidth(4);		//mode
    grg->SetLineStyle(9);		//mode
    grg->Draw("L");
//
    gr6 = new TGraph(ne,E6,SED6);
    gr6->SetLineColor(6);		//for line
    gr6->SetLineWidth(2);		//mode
    gr6->Draw("L");
//
    grh6 = new TGraph(ne,Eh6,SEDh6);
    grh6->SetMarkerColor(6);
    grh6->SetMarkerSize(1.0);
    grh6->SetMarkerStyle(8);
    grh6->Draw("P");
//
    c1->Update();
    c1->GetFrame()->SetFillColor(0);
    c1->GetFrame()->SetBorderMode(0);
    c1->GetFrame()->SetBorderSize(0);
    c1->SaveAs("Fig08.eps");
    c1->SaveAs("Fig08.jpg");
    if (gSystem->ProcessEvents()) break;
    c1->Modified();
}
