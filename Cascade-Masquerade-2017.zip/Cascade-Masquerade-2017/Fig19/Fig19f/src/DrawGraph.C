#include "src/Functions.cpp"

int DrawGraph()
{
    Double_t Sfull[nbin2], E2[nbin2], S2[nbin2], Smod[nbin2], S0mod[nbin2];
//
    L_sec *= norm_exp;
    L_abs *= norm_exp;
    for (int i = 0; i < nbin; i++)
    {
        S_exp[i] *= norm_exp;
        S_stat[i] *= norm_exp;
        S_stat_p[i] *= norm_exp;
        S_stat_m[i] *= norm_exp;
    }
//
    for (int i = 0; i < nbin; i++)
        S0_mod[i] = pow(E_exp[i],2 - gamma) * exp(-E_exp[i]/Ec);
    exponent(nbin, E_exp, S_mod, S0_mod, -1);
//
    for (int i = 0; i < nbin; i++)
        norm_mod += S_mod[i];
//
    free(S0_mod);
    free(S_mod);
    S0_mod = new double[nbin2];
    S_mod = new double[nbin2];
    for (int i = 0; i < nbin2; i++)
    {
        S0_mod[i] = pow(E_2[i],2 - gamma) * exp(-E_2[i]/Ec);
        S0_mod[i] /= norm_mod;
        S0_mod[i] *= L_abs;
    }
    exponent(nbin2, E_2, S_mod, S0_mod, -1);
//
    for (int i = 0; i < nbin2; i++)
    {
        E2[i] = E_2[i];
        S2[i] = S_2[i] * L_sec;
        Smod[i] = S_mod[i];
        S0mod[i] = S0_mod[i];
        Sfull[i] = Smod[i] + S2[i];
    }
//Init ROOT:
    gStyle->SetOptStat(0);
    gStyle->SetPalette(1);
    gStyle->SetCanvasColor(1);
    gStyle->SetFrameFillColor(1);
    TCanvas *c1 = new TCanvas("c1",graph_title,0,0,1200,1000);
    c1->GetFrame()->SetBorderMode(-1);
    c1->SetFillColor(0);
    c1->SetLogx();
    c1->SetLogy();
//Draw histogram to zoom graphs:
    h= new TH2F("","",30,0.2,40.0,30,5.0e-15,1.0e-9); //log
    h->GetXaxis()->SetTitle("E [TeV]");
    h->GetYaxis()->SetTitle("SED [TeVcm^{-2}s^{-1}]");
    h->GetXaxis()->SetTitleOffset(1.4);
    h->GetYaxis()->SetTitleOffset(1.5);
    h->SetStats(kFALSE);
    h->Draw();
//DRAW:
    GrSexp = new TGraphAsymmErrors(nbin,E_exp,S_exp,NULL,NULL,S_stat_m,S_stat_p);
    GrSexp->SetTitle(graph_title);
    GrSexp->SetMarkerColor(2);
    GrSexp->SetMarkerStyle(8);
    GrSexp->SetMarkerSize(1.5);
    GrSexp->SetLineWidth(2);
    GrSexp->SetLineColor(2);
    GrSexp->Draw("P");
//
    GrS2 = new TGraph(nbin2,E2,S2);
    GrS2->SetLineColor(3);
    GrS2->SetLineWidth(2);
    GrS2->SetLineStyle(1);
    GrS2->Draw("L");
//
    GrS2 = new TGraph(nbin2,E2,Sfull);
    GrS2->SetLineColor(4);
    GrS2->SetLineWidth(2);
    GrS2->SetLineStyle(1);
    GrS2->Draw("L");
//
    GrS0mod = new TGraph(nbin2,E2,S0mod);
    GrS0mod->SetLineColor(1);
    GrS0mod->SetLineWidth(2);
    GrS0mod->SetLineStyle(9);
    GrS0mod->Draw("L");
//
    GrSmod = new TGraph(nbin2,E2,Smod);
    GrSmod->SetLineColor(1);
    GrSmod->SetLineWidth(2);
    GrSmod->SetLineStyle(1);
    GrSmod->Draw("L");
//
    c1->Update();
    c1->GetFrame()->SetFillColor(0);
    c1->GetFrame()->SetBorderMode(0);
    c1->GetFrame()->SetBorderSize(0);
    c1->SaveAs("Fig19f.eps");
    c1->SaveAs("Fig19f.jpg");
    if (gSystem->ProcessEvents()) break;
    c1->Modified();
//
    double p = TMath::Prob(chisq_min, nbin - 4);
    double Z = sqrt(2.0)*TMath::ErfcInverse(2.0*p);
    cout << "************" << endl;
    cout << "p = " << p << "   " << "Z = " << Z << endl;
    FILE *fp = fopen(name_file, "w");
    fprintf(fp, "gamma = %lf\nE_c = %lf\nL_abs = %le\nL_sec = %le\n",gamma, Ec, L_abs, L_sec);
    fprintf(fp, "chisq_min = %lf \n", chisq_min);
    fprintf(fp, "chisq_min_red = %lf \n", chisq_min/(nbin - 4));
    fprintf(fp, "p = %lf\nZ = %lf\n",p,Z);
    fclose(fp);
}
