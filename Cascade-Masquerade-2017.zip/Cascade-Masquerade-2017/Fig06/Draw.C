{
#include "stdio.h"
#include "stdlib.h"
#include "math.h"

    gROOT->Reset();
    gStyle->SetOptStat(0);
    gStyle->SetPalette(1);
    gStyle->SetCanvasColor(1);
    gStyle->SetFrameFillColor(1);
    TCanvas *c1 = new TCanvas("c1","Diffuse Gamma Spectra",10,10,1100,900);
    c1->GetFrame()->SetBorderMode(-1);
    c1->SetFillColor(0);
    c1->SetLogx();
    c1->SetLogy();
//
    const Int_t ne= 100;
    const Int_t nc= 401;
    const Double_t bigd= 1.0e40;
    const Int_t PrintFlag= 0;
//
    int i,j,n1,n2;
    double rd,eps,Et1,Et2;
    double delta,min,k;
//
    double E1[ne],SED1[ne];
    double E2[ne],SED2[ne];
    double Ec[nc],SEDc[nc]; //combined SED
    double ELine[ne],SEDLine[ne];
    FILE *fp;
//
    fp= fopen("HighThr-0186","r");
    if (fp==NULL)
    {
	printf("Error: input file1 not found!\n");
	return;
    }
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); E1[i]= rd;
	fscanf(fp,"%lf",&rd); SED1[i]= 7.7e-33*rd/1.254249;
    }
    for (i=0; i<ne; i++)
	E1[i]= E1[i]*1.0e-12;
    fclose(fp);
//
    fp= fopen("LowThr-0186","r");
    if (fp==NULL)
    {
	printf("Error: input file2 not found!\n");
	return;
    }
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); E2[i]= rd;
	fscanf(fp,"%lf",&rd); SED2[i]= 0.57*7.7e-33*rd/1.254249;
    }
    for (i=0; i<ne; i++)
	E2[i]= E2[i]*1.0e-12;
    fclose(fp);
//
    h= new TH2F("","",30,1.0e-5,1.0e2,30,1.0e-2,2.0);
    h->SetTitle("");
    h->GetXaxis()->SetTitle("E [TeV]");
    h->GetYaxis()->SetTitle("SED [arb. units]");
    h->GetXaxis()->SetTitleOffset(1.2);
    h->GetYaxis()->SetTitleOffset(0.8);
    h->SetStats(kFALSE);
    h->Draw();
//
    Gr1 = new TGraph(ne,E1,SED1);
    Gr1->SetLineColor(7);
    Gr1->SetLineWidth(4);
    Gr1->Draw("L");
    for (i=0; i<ne; i++)
	printf("%13.6e %13.6e\n",E1[i],SED1[i]);
//
    Gr2 = new TGraph(ne,E2,SED2);
    Gr2->SetLineColor(6);
    Gr2->SetLineStyle(9);		//for line
    Gr2->SetLineWidth(4);
    Gr2->Draw("L");
//
    for (i=0; i<ne; i++)
    {
	ELine[i]= 1.00e7*pow(10.0,0.014*i);
	SEDLine[i]= 0.145*pow(ELine[i]/1.0e7,0.4)/1.254249;
    }
    for (i=0; i<ne; i++)
	ELine[i]= ELine[i]*1.0e-12;
//
    GrLine1 = new TGraph(ne,ELine,SEDLine);
    GrLine1->SetLineColor(1);		//for line
    GrLine1->SetLineWidth(2);		//mode
    GrLine1->Draw("L"); //axis+markers (red circles)
//
    for (i=0; i<ne; i++)
    {
	ELine[i]= 2.30e8*pow(10.0,0.0298*i);
	SEDLine[i]= 0.32*pow(ELine[i]/1.0e7,0.15)/1.254249;
    }
    for (i=0; i<ne; i++)
	ELine[i]= ELine[i]*1.0e-12;
//
    GrLine2 = new TGraph(ne,ELine,SEDLine);
    GrLine2->SetLineColor(2);		//for line
    GrLine2->SetLineWidth(2);		//mode
    GrLine2->Draw("L"); //axis+markers (red circles)
//
    for (i=0; i<ne; i++)
    {
	ELine[i]= 2.00e11*pow(10.0,0.0192*i);
	SEDLine[i]= 0.75*pow(ELine[i]/1.0e12,-0.4)/1.254249;
    }
    for (i=0; i<ne; i++)
	ELine[i]= ELine[i]*1.0e-12;
//
    GrLine3 = new TGraph(ne,ELine,SEDLine);
    GrLine3->SetLineColor(3);		//for line
    GrLine3->SetLineWidth(2);		//mode
    GrLine3->Draw("L"); //axis+markers (red circles)
//
    for (i=0; i<ne; i++)
    {
	ELine[i]= 1.52e13*pow(10.0,0.03*i);
	SEDLine[i]= 60.0*pow(ELine[i]/1.0e12,-2.0)/1.254249;
    }
    for (i=0; i<ne; i++)
	ELine[i]= ELine[i]*1.0e-12;
//
    GrLine4 = new TGraph(ne,ELine,SEDLine);
    GrLine4->SetLineColor(4);		//for line
    GrLine4->SetLineWidth(2);		//mode
    GrLine4->Draw("L"); //axis+markers (red circles)
//
    eps= 1.0e5;
    Et1= E1[0]-eps;
    Et2= E1[ne-1]+eps;
    fp= fopen("CombinedSpec","w");
    if (PrintFlag>0)
    {
	fprintf(fp,"%13.6e %13.6e\n",Et1,Et2);
	fprintf(fp,"\n");
    }
//
    for (i=0; i<nc; i++)
    {
	Ec[i]= 1.0*pow(10.0,4.0e-2*(i+0.5));
	if ((Ec[i]>1.0e11-eps)&&(Ec[i]<Et2+eps)) //E= 100 GeV --- 100 TeV
	{ //directly set values from high-threshold, high-statistics spectrum
	    if (PrintFlag>0)
		fprintf(fp,"%8d %8d  %13.6e %13.6e\n",i,i-250,Ec[i],E1[i-250]);
	    SEDc[i]= SED1[i-250];
	}
	else if (Ec[i]>Et2-eps) //high-energy part of the spectrum (E>100 TeV)
	    SEDc[i]= 60.0*pow(Ec[i]/1.0e12,-2.0);
	else if (Ec[i]<E2[0]+eps) //low-energy part of the spectrum (E<10 MeV)
	    SEDc[i]= 0.145*pow(Ec[i]/1.0e7,0.4);
	else //E= 10 MeV --- 100 GeV
	{ //inrerpolate from low-threshold spectrum, low-statistics spectrum
	    n1= 0;
	    n2= 1;
	    min= bigd;
	    for (j=0; j<ne; j++)
	    {
		delta= fabs(E2[j]-Ec[i]);
		if ((E2[j]<=Ec[i])&&(delta<min))
		{
		    min= delta;
		    n1= j;
		}
	    }
	    n2= n1+1;
	    k= (Ec[i]-E2[n1])/(E2[n2]-E2[n1]);
	    SEDc[i]= (1.0-k)*SED2[n1]+k*SED2[n2]; //interpolate
	    if (PrintFlag>0)
		fprintf(fp,"n1= %8d n2= %8d k= %13.6e\n",n1,n2,k);
	}
    }
    if (PrintFlag>0)
	fprintf(fp,"\n");
    for (i=0; i<nc; i++)
	fprintf(fp,"%13.6e %13.6e\n",Ec[i],SEDc[i]);
    fclose(fp);
//
    c1->Update();
    c1->GetFrame()->SetFillColor(0);
    c1->GetFrame()->SetBorderMode(0);
    c1->GetFrame()->SetBorderSize(0);
    c1->SaveAs("Fig06.eps");
    c1->SaveAs("Fig06.jpg");
    if (gSystem->ProcessEvents()) break;
    c1->Modified();
}
