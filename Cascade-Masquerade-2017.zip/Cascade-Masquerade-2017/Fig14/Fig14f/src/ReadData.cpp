#include <fstream>
#include "Functions.cpp"

#define SMALLD 1.0e-40

void ReadData()
{
    FILE *fp;
    ifstream fpp;
    char name_exp[50], name_MySpec[50];
    double tmpd;
    int tmpi;

    double weight;
    double z;

    fpp.open("input");
    fpp >> name_exp >> name_MySpec >> graph_title >> name_graph >> name_file;
    fpp.close();
//
    fp = fopen(name_exp,"r");
    if (fp == NULL) cout << "wrong filename in input file" << endl;
    fscanf(fp,"%d %le",&nbin, &z0);
    E_exp = new double[nbin];
    S_exp = new double[nbin];
    S_stat_m = new double[nbin];
    S_stat_p = new double[nbin];
    S_stat = new double[nbin];
    S_mod = new double[nbin];
    S0_mod = new double[nbin];
    for (int i = 0; i < nbin; i++)
    {
	fscanf(fp, "%d", &tmpi);
        fscanf(fp, "%le", &E_exp[i]);
        fscanf(fp, "%le", &tmpd);
        fscanf(fp, "%le", &tmpd);
        fscanf(fp, "%le", &S_exp[i]); // dN/dE
        S_exp[i] *= E_exp[i]*E_exp[i]; // E^2*dN/dE
        norm_exp += S_exp[i];
        fscanf(fp, "%le", &S_stat_p[i]);
        fscanf(fp, "%le", &S_stat_m[i]);
        S_stat_p[i] *= E_exp[i]*E_exp[i];
        S_stat_m[i] *= -E_exp[i]*E_exp[i];
        if (S_stat_p[i] > S_stat_m[i]) S_stat[i] = S_stat_p[i];
        else S_stat[i] = S_stat_m[i];
        for (int j = 0; j < 2; j++)
            fscanf(fp, "%le", &tmpd);
    }
    fclose(fp);
//
    if (fabs(norm_exp)>SMALLD)
    {
        for (int i = 0; i < nbin; i++)
	{
	    S_exp[i]    /= norm_exp;
	    S_stat[i]   /= norm_exp;
	    S_stat_p[i] /= norm_exp;
	    S_stat_m[i] /= norm_exp;
	}
    }
//
    fp = fopen("data/Tau-0129-0287","r");
    n_E = 100;
    int n_z = 4;
    double eps,delta,z_tau;
    z_tau = new double[n_E];
    E_tau = new double[n_E];
    tau = new double[n_E];
    tmpi = 0;
    eps= 5.0e-2;
//
    int i,s;
    double rd;
    double ETemp[400],ZTemp[400],TauTemp[400];
//
    for (i=0; i<400; i++)
    {
	fscanf(fp,"%lf",&rd); ETemp[i]= rd;
	fscanf(fp,"%lf",&rd); ZTemp[i]= rd;
	fscanf(fp,"%lf",&rd); TauTemp[i]= rd;
    }
    fclose(fp);
//
    s= 0;
    for (i=0; i<400; i++)
    {
	delta= 1.0;
	if (fabs(ZTemp[i])>SMALLD)
	    delta= fabs(ZTemp[i]-z0)/ZTemp[i];
	if (delta<eps)
	{
	    E_tau[s]= 1e-12*ETemp[i];
	    z_tau[s]= ZTemp[i];
	    tau[s]= TauTemp[i];
	    s++;
	}
    }
    FILE *fpt;
    fpt= fopen("Test","w");
    for (i=0; i<n_E; i++)
	fprintf(fpt,"%13.6e %13.6e %13.6e\n",z_tau[i],E_tau[i],tau[i]);
    fclose(fpt);
//
    fp = fopen(name_MySpec, "r");
    for (int i = 0; i < 5; i++)
		fscanf(fp, "%le", &tmpd);
    E_2 = new double[nbin2];
    S_2 = new double[nbin2];
    for (int i = 0; i < nbin2; i++)
    {
		E_2[i]=0;
		S_2[i]=0;
	}
    for (int i = 0; i < nbin2; i++)
		fscanf(fp, "%le %le", &E_2[i], &S_2[i]);
	for (int i = 0; i < nbin2; i++)
		E_2[i] *= 1e-12;
    fclose(fp);
//
    L_sec = 0;
    for (int i = 0; i < nbin2; i++)
        L_sec += S_2[i];
    for (int i = 0; i < nbin2; i++)
        S_2[i] /= L_sec;
}
