int Draw()
{
    const int nbin;
    double tmpd;
    int tmpi;
    double *E_exp, *S_exp, *S_stat_m, *S_stat_p;
    const int nbin2 = 100;
    Double_t E1[nbin2],S1[nbin2],E2[nbin2],S2[nbin2],E3[nbin2],S3[nbin2],E4[nbin2],S4[nbin2],E5[nbin2],S5[nbin2];
//
    FILE *fp = fopen("014full","r");
    if (fp == NULL) cout << "wrong filename in input file" << endl;
    fscanf(fp,"%d %le",&nbin, &tmpd);
    E_exp = new double[nbin];
    S_exp = new double[nbin];
    S_stat_m = new double[nbin];
    S_stat_p = new double[nbin];
    for (int i = 0; i < nbin; i++)
    {
        fscanf(fp,"%d",&tmpi);
        fscanf(fp, "%le", &E_exp[i]);		//center of the bin [TeV]
        fscanf(fp, "%le", &tmpd);		//start  of the bin [TeV]
        fscanf(fp, "%le", &tmpd);		//end    of the bin [TeV]
        fscanf(fp, "%le", &S_exp[i]);		//dN/dE
        S_exp[i] *= E_exp[i]*E_exp[i];		//SED= E^2*dN/dE
        fscanf(fp, "%le", &S_stat_p[i]);	//stat. uncertainty +
        fscanf(fp, "%le", &S_stat_m[i]);	//stat. uncertainty -
        S_stat_p[i] *= E_exp[i]*E_exp[i];
        S_stat_m[i] *= -E_exp[i]*E_exp[i];
        for (int j = 0; j < 2; j++)
            fscanf(fp, "%le", &tmpd);		//syst. uncertainties (ignore!)
    }
    fclose(fp);
//
    fp = fopen("outspec-zc000","r");
    for (int i = 0; i < nbin2; i++)
		fscanf(fp,"%le %le",&E1[i],&S1[i]);
	fclose(fp);
//
    fp = fopen("outspec-zc002","r");
    for (int i = 0; i < nbin2; i++)
		fscanf(fp,"%le %le",&E2[i],&S2[i]);
	fclose(fp);
//
    fp = fopen("outspec-zc005","r");
    for (int i = 0; i < nbin2; i++)
		fscanf(fp,"%le %le",&E3[i],&S3[i]);
	fclose(fp);
//
    fp = fopen("outspec-zc010","r");
    for (int i = 0; i < nbin2; i++)
		fscanf(fp,"%le %le",&E4[i],&S4[i]);
	fclose(fp);
//
	fp = fopen("outspec-pwl","r");
    for (int i = 0; i < nbin2; i++)
		fscanf(fp,"%le %le",&E5[i],&S5[i]);
	fclose(fp);
//
    gStyle->SetOptStat(0);
    gStyle->SetPalette(1);
    gStyle->SetCanvasColor(1);
    gStyle->SetFrameFillColor(1);
    TCanvas *c1 = new TCanvas("c1","BLACK:zc=0,MAGENTA:zc=0.02,GREEN:zc=0.05,BLUE:zc=0.1;BLACK_DASHED=PWL",0,0,1200,1000);
    c1->GetFrame()->SetBorderMode(-1);
    c1->SetFillColor(0);
    c1->SetLogx();
    c1->SetLogy();
//Draw histogram to zoom graphs:
    h= new TH2F("","",30,0.2,15,30,1e-14,1e-11); //log
    h->GetXaxis()->SetTitle("E [TeV]");
    h->GetYaxis()->SetTitle("SED [TeVcm^{-2}s^{-1}]");
    h->GetXaxis()->SetTitleOffset(1.2);
    h->GetYaxis()->SetTitleOffset(1.4);
    h->SetStats(kFALSE);
    h->Draw();
//DRAW:
//draw small symbols (!!!!!!!!) and statistical uncertainties
    GrSexp = new TGraphAsymmErrors(nbin,E_exp,S_exp,NULL,NULL,S_stat_m,S_stat_p);
    GrSexp->SetMarkerColor(1);
    GrSexp->SetMarkerStyle(8);
    GrSexp->SetMarkerSize(0.5);
    GrSexp->SetLineColor(2);
    GrSexp->SetLineWidth(2);
    GrSexp->Draw("P");
//draw VERITAS and HESS separately (!!!!!!!!)
    const Int_t nbin20= 9;
    const Int_t nbin30= 8;
    int s2,s3;
    Double_t E20[100];
    Double_t S20[100];
    Double_t E30[100];
    Double_t S30[100];
    s2= 0;
    s3= 0;
    for (i=0; i<nbin; i++)
    {
	if ((i==0)||(i==1)||(i==3)||(i==5)||(i==7)||(i==9)||(i==11)||(i==13)||(i==15))
	{
	    E20[s2]= E_exp[i];
	    S20[s2]= S_exp[i];
	    s2++;
	}
    }
    for (i=0; i<nbin; i++)
    {
	if ((i==2)||(i==4)||(i==6)||(i==8)||(i==10)||(i==12)||(i==14)||(i==16))
	{
	    E30[s3]= E_exp[i];
	    S30[s3]= S_exp[i];
	    s3++;
	}
    }
//
    Gr2 = new TGraph(nbin20,E20,S20);
    Gr2->SetMarkerColor(2);
    Gr2->SetMarkerStyle(8);
    Gr2->SetMarkerSize(1.5);
    Gr2->Draw("P");
//
    Gr3= new TGraph(nbin30,E30,S30);
    Gr3->SetMarkerColor(2);
    Gr3->SetMarkerStyle(22);
    Gr3->SetMarkerSize(1.5);
    Gr3->Draw("P");
//
    Gr1 = new TGraph(nbin2,E1,S1); //ZC = 0 => BLACK
    Gr1->SetLineColor(1);
    Gr1->SetLineWidth(2);
    Gr1->SetLineStyle(1);
    Gr1->Draw("L");
//
    Gr2 = new TGraph(nbin2,E2,S2); //ZC = 0.02 => MAGENTA
    Gr2->SetLineColor(6);
    Gr2->SetLineWidth(2);
    Gr2->SetLineStyle(1);
    Gr2->Draw("L");
//
    Gr3 = new TGraph(nbin2,E3,S3); //ZC = 0.05 => GREEN
    Gr3->SetLineColor(3);
    Gr3->SetLineWidth(2);
    Gr3->SetLineStyle(1);
    Gr3->Draw("L");
//
    Gr4 = new TGraph(nbin2,E4,S4); //ZC = 0.1 => BLUE
    Gr4->SetLineColor(4);
    Gr4->SetLineWidth(2);
    Gr4->SetLineStyle(1);
    Gr4->Draw("L");
//
    Gr5 = new TGraph(nbin2,E5,S5); //PWL = BLACK DASHED
    Gr5->SetLineColor(1);
    Gr5->SetLineWidth(4);
    Gr5->SetLineStyle(7);
    Gr5->Draw("L");
//
    c1->Update();
    c1->GetFrame()->SetFillColor(0);
    c1->GetFrame()->SetBorderMode(0);
    c1->GetFrame()->SetBorderSize(0);
    c1->SaveAs("Fig14e.eps");
    c1->SaveAs("Fig14e.jpg");
    if (gSystem->ProcessEvents()) break;
    c1->Modified();
}
