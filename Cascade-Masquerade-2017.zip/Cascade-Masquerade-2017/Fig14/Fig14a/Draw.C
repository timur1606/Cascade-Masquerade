{
#include "stdio.h"
#include "stdlib.h"
#include "math.h"

    gROOT->Reset();
    gStyle->SetOptStat(0);
    gStyle->SetPalette(1);
    gStyle->SetCanvasColor(1);
    gStyle->SetFrameFillColor(1);
    TCanvas *c1 = new TCanvas("c1","Diffuse Gamma Spectra",10,10,1100,900);
    c1->GetFrame()->SetBorderMode(-1);
    c1->SetFillColor(0);
    c1->SetLogx();
    c1->SetLogy();
//
    const Int_t ne= 100;
    int i;
    double rd;
//
    double Epg12[ne],SEDpg12[ne];
    double Eag12[ne],SEDag12[ne];
//
    double Epf12[ne],SEDpf12[ne];
    double Eaf12[ne],SEDaf12[ne];
//
    double Epe12[ne],SEDpe12[ne];
    double Eae12[ne],SEDae12[ne];
//observed SED
    int nbe;
    double zs,delta;
    double Ee[ne],Emin[ne],Emax[ne],ObsSpec[ne];
    double StatP[ne],StatM[ne],SystP[ne],SystM[ne];
    double EErr[ne],SEDErrP[ne],SEDErrM[ne];
//
    double ObsSED[ne],DeltaObsSED[ne];
//
    FILE *fp;
    h= new TH2F("","",30,0.1,12.0,30,1.0e-14,6.0e-12);
    h->SetTitle("");
    h->GetXaxis()->SetTitle("E [TeV]");
    h->GetYaxis()->SetTitle("SED [TeVcm^{-2}s^{-1}]");
    h->GetXaxis()->SetTitleOffset(1.2);
    h->GetYaxis()->SetTitleOffset(1.4);
    h->SetStats(kFALSE);
    h->Draw();
//
    fp= fopen("071-Aliu14a","r");
    if (fp==NULL)
    {
	printf("Error: observed spectrum file not found!\n");
	return;
    }
//
    fscanf(fp,"%d",&nbe);
    fscanf(fp,"%lf",&zs);
    for (i=0; i<nbe; i++)
    {
	fscanf(fp,"%lf",&rd); Ee[i]     = rd;			//energy
	fscanf(fp,"%lf",&rd); Emin[i]   = rd;			//min energy
	fscanf(fp,"%lf",&rd); Emax[i]   = rd;			//max energy
	fscanf(fp,"%lf",&rd); ObsSpec[i]= rd;			//intensity (dN/dE)
	fscanf(fp,"%lf",&rd); StatP[i]  = rd;			//statistical uncertainty
	fscanf(fp,"%lf",&rd); StatM[i]  = rd;			//statistical uncertainty
	fscanf(fp,"%lf",&rd); SystP[i]  = rd;			//systematic uncertainty (+)
	fscanf(fp,"%lf",&rd); SystM[i]  = rd;			//systematic uncertainty (-)
    }
    fclose(fp);
//
    for (i=0; i<nbe; i++)
    {
	EErr[i]= 0.0;
	delta= (fabs(StatP[i])+fabs(StatM[i]))/2.0;
	ObsSED[i]     = Ee[i]*Ee[i]*ObsSpec[i];
	SEDErrP[i]    = Ee[i]*Ee[i]*fabs(StatP[i]);
	SEDErrM[i]    = Ee[i]*Ee[i]*fabs(StatM[i]);
	DeltaObsSED[i]= Ee[i]*Ee[i]*delta;
    }
//
    GrExp = new TGraphAsymmErrors(nbe,Ee,ObsSED,EErr,EErr,SEDErrM,SEDErrP);
    GrExp->SetLineColor(2);			//for line mode
    GrExp->SetLineWidth(2);			
    GrExp->SetMarkerColor(2);			//2= red
    GrExp->SetMarkerStyle(8);			//29= stars
    GrExp->SetMarkerSize(2.0);
    GrExp->Draw("P");				//markers
//
    fp= fopen("FitCurves_z0.140_G","r");
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Epg12[i]= rd;
	fscanf(fp,"%lf",&rd); SEDpg12[i]= rd;
    }
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Eag12[i]= rd;
	fscanf(fp,"%lf",&rd); SEDag12[i]= rd;
    }
    fclose(fp);
//
    grpg12 = new TGraph(ne,Epg12,SEDpg12);
    grpg12->SetLineColor(1);
    grpg12->SetLineWidth(2);
    grpg12->SetLineStyle(9);
    grpg12->Draw("L");
//
    grag12 = new TGraph(ne,Eag12,SEDag12);
    grag12->SetLineColor(1);
    grag12->SetLineWidth(2);
    grag12->Draw("L");
//
    fp= fopen("FitCurves_z0.140_F","r");
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Epf12[i]= rd;
	fscanf(fp,"%lf",&rd); SEDpf12[i]= rd;
    }
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Eaf12[i]= rd;
	fscanf(fp,"%lf",&rd); SEDaf12[i]= rd;
    }
    fclose(fp);
//
    grpf12 = new TGraph(ne,Epf12,SEDpf12);
    grpf12->SetLineColor(3);
    grpf12->SetLineWidth(2);
    grpf12->SetLineStyle(9);
    grpf12->Draw("L");
//
    graf12 = new TGraph(ne,Eaf12,SEDaf12);
    graf12->SetLineColor(3);
    graf12->SetLineWidth(2);
    graf12->Draw("L");
//
    fp= fopen("Fit_ELMAG_0.140_new","r");
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Epe12[i]= rd;
	fscanf(fp,"%lf",&rd); SEDpe12[i]= rd;
    }
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Eae12[i]= rd;
	fscanf(fp,"%lf",&rd); SEDae12[i]= rd;
    }
    fclose(fp);
//
    grpe12 = new TGraph(ne,Epe12,SEDpe12);
    grpe12->SetLineColor(4);
    grpe12->SetLineWidth(2);
    grpe12->SetLineStyle(9);
    grpe12->Draw("L");
//
    grae12 = new TGraph(ne,Eae12,SEDae12);
    grae12->SetLineColor(4);
    grae12->SetLineWidth(2);
    grae12->Draw("L");
//
    c1->Update();
    c1->GetFrame()->SetFillColor(0);
    c1->GetFrame()->SetBorderMode(0);
    c1->GetFrame()->SetBorderSize(0);
    c1->SaveAs("Fig12.eps");
    c1->SaveAs("Fig12.jpg");
    if (gSystem->ProcessEvents()) break;
    c1->Modified();
}
