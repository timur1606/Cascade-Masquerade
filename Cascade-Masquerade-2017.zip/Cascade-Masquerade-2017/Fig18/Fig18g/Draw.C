int Draw()
{
	const int nbin;
	double tmpd;
	int tmpi;
	double *E_exp, *S_exp, *S_stat_m, *S_stat_p;
	const int nbin2 = 100;
	Double_t E1[nbin2],S1[nbin2],E2[nbin2],S2[nbin2],E3[nbin2],S3[nbin2],E4[nbin2],S4[nbin2],E5[nbin2],S5[nbin2];

    FILE *fp = fopen("087-HESS12b","r");
    if (fp == NULL) cout << "wrong filename in input file" << endl;
    fscanf(fp,"%d %le",&nbin, &tmpd);
    E_exp = new double[nbin];
    S_exp = new double[nbin];
    S_stat_m = new double[nbin];
    S_stat_p = new double[nbin];
    for (int i = 0; i < nbin; i++)
    {
        fscanf(fp, "%le", &E_exp[i]);
        fscanf(fp, "%le", &tmpd);
        fscanf(fp, "%le", &tmpd);
        fscanf(fp, "%le", &S_exp[i]); // dN/dE
        S_exp[i] *= E_exp[i]*E_exp[i]; // E^2*dN/dE
        fscanf(fp, "%le", &S_stat_p[i]);
        fscanf(fp, "%le", &S_stat_m[i]);
        S_stat_p[i] *= E_exp[i]*E_exp[i];
        S_stat_m[i] *= -E_exp[i]*E_exp[i];
        for (int j = 0; j < 2; j++)
            fscanf(fp, "%le", &tmpd);
    }
    fclose(fp);

    fp = fopen("outspec-zc000","r");
    for (int i = 0; i < nbin2; i++)
		fscanf(fp,"%le %le",&E1[i],&S1[i]);
	fclose(fp);

    fp = fopen("outspec-zc025","r");
    for (int i = 0; i < nbin2; i++)
		fscanf(fp,"%le %le",&E4[i],&S4[i]);
	fclose(fp);
    //Init ROOT:
    gStyle->SetOptStat(0);
    gStyle->SetPalette(1);
    gStyle->SetCanvasColor(1);
    gStyle->SetFrameFillColor(1);
    TCanvas *c1 = new TCanvas("c1","BLACK:zc=0,BLUE:zc=0.25",0,0,1200,1000);
    c1->GetFrame()->SetBorderMode(-1);
    c1->SetFillColor(0);
    c1->SetLogx();
    c1->SetLogy();

    //Draw histogram to zoom graphs:
    h= new TH2F("","",30,0.1,2,30,1e-14,3e-12); //log
    h->GetXaxis()->SetTitle("E [TeV]");
    h->GetYaxis()->SetTitle("SED [TeVcm^{-2}s^{-1}]");
    h->GetXaxis()->SetTitleOffset(1.4);
    h->GetYaxis()->SetTitleOffset(1.5);
    h->SetStats(kFALSE);
    h->Draw();
    //DRAW:
//draw small symbols (!!!!!!!!) and statistical uncertainties
    GrSexp = new TGraphAsymmErrors(nbin,E_exp,S_exp,NULL,NULL,S_stat_m,S_stat_p);
    GrSexp->SetMarkerColor(2);
    GrSexp->SetMarkerStyle(8);
    GrSexp->SetMarkerSize(1.5);
    GrSexp->SetLineColor(2);
    GrSexp->SetLineWidth(2);
    GrSexp->Draw("P");

    Gr1 = new TGraph(nbin2,E1,S1); //ZC = 0 => BLACK
    Gr1->SetLineColor(1);
    Gr1->SetLineWidth(2);
    Gr1->SetLineStyle(1);
    Gr1->Draw("L");

    Gr4 = new TGraph(nbin2,E4,S4); //ZC = 0.1 => BLUE
    Gr4->SetLineColor(4);
    Gr4->SetLineWidth(2);
    Gr4->SetLineStyle(1);
    Gr4->Draw("L");

    c1->Update();
    c1->GetFrame()->SetFillColor(0);
    c1->GetFrame()->SetBorderMode(0);
    c1->GetFrame()->SetBorderSize(0);
    c1->SaveAs("Fig18g.eps");
    c1->SaveAs("Fig18g.jpg");
    if (gSystem->ProcessEvents()) break;
    c1->Modified();
}
