{
#include "stdio.h"
#include "stdlib.h"
#include "math.h"

    gROOT->Reset();
    gStyle->SetOptStat(0);
    gStyle->SetPalette(1);
    gStyle->SetCanvasColor(1);
    gStyle->SetFrameFillColor(1);
    TCanvas *c1 = new TCanvas("c1","Diffuse Gamma Spectra",10,10,1100,900);
    c1->GetFrame()->SetBorderMode(-1);
    c1->SetFillColor(0);
    c1->SetLogx();
    c1->SetLogy();
//
    const Int_t nep= 101;
    const Int_t nee= 140;
    int n,j,k;
    double z,rd,K;
    double Ep[nep];
    double Ee[nee];
    double SED[nep][nee];
    Double_t TestSED[nee];
    FILE *fp;
//Draw histogram to zoom graphs
    h= new TH2F("","",30,1.0e14,1.0e20,30,1.0e-8,10.0); //gamma
    h->SetTitle("");
    h->GetXaxis()->SetTitle("E [eV]");
    h->GetYaxis()->SetTitle("SED [arb. units]");
    h->GetXaxis()->SetTitleOffset(1.5);
    h->GetYaxis()->SetTitleOffset(1.0);
    h->SetStats(kFALSE);
    h->Draw();
//
    fp= fopen("GammaSED","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
//read z
    fscanf(fp,"%lf",&z);
//read data
    for (j=0; j<nep; j++)
    {
	fscanf(fp,"%lf",&rd);
	Ep[j]= rd;
    }
    for (j=0; j<nee; j++)
    {
	fscanf(fp,"%lf",&rd);
	Ee[j]= rd;
	for (k=0; k<nep; k++)
	{
	    fscanf(fp,"%lf",&rd);
	    SED[k][j]= rd;
	}
    }
//
    K= 1.0/3.0e8;
    n= 100;
    printf("Ep= %13.6e\n",Ep[n]);
    for (j=0; j<nee; j++)
	TestSED[j]= K*SED[n][j];
//
    grg1 = new TGraph(nee,Ee,TestSED);
    grg1->SetLineColor(4);		//for line
    grg1->SetLineWidth(2);		//mode
    grg1->Draw("L"); //axis+markers (red circles)
//
    n= 92;
    printf("Ep= %13.6e\n",Ep[n]);
    for (j=0; j<nee; j++)
	TestSED[j]= K*SED[n][j];
//
    grg2 = new TGraph(nee,Ee,TestSED);
    grg2->SetLineColor(3);		//for line
    grg2->SetLineWidth(2);		//mode
    grg2->Draw("L"); //axis+markers (red circles)
//
    n= 85;
    printf("Ep= %13.6e\n",Ep[n]);
    for (j=0; j<nee; j++)
	TestSED[j]= K*SED[n][j];
//
    grg3 = new TGraph(nee,Ee,TestSED);
    grg3->SetLineColor(2);		//for line
    grg3->SetLineWidth(2);		//mode
    grg3->Draw("L"); //axis+markers (red circles)
//
    n= 74;
    printf("Ep= %13.6e\n",Ep[n]);
    for (j=0; j<nee; j++)
	TestSED[j]= K*SED[n][j];
//
    grg4 = new TGraph(nee,Ee,TestSED);
    grg4->SetLineColor(1);		//for line
    grg4->SetLineWidth(2);		//mode
    grg4->Draw("L"); //axis+markers (red circles)
//
    fp= fopen("PositronSED","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
//read z
    fscanf(fp,"%lf",&z);
//read data
    for (j=0; j<nep; j++)
    {
	fscanf(fp,"%lf",&rd);
	Ep[j]= rd;
    }
    for (j=0; j<nee; j++)
    {
	fscanf(fp,"%lf",&rd);
	Ee[j]= rd;
	for (k=0; k<nep; k++)
	{
	    fscanf(fp,"%lf",&rd);
	    SED[k][j]= rd;
	}
    }
//
    K= 1.0/3.0e8;
    n= 100;
    printf("Ep= %13.6e\n",Ep[n]);
    for (j=0; j<nee; j++)
	TestSED[j]= K*SED[n][j];
//
    grp1 = new TGraph(nee,Ee,TestSED);
    grp1->SetLineColor(4);		//for line
    grp1->SetLineStyle(9);		//for line
    grp1->SetLineWidth(2);		//mode
    grp1->Draw("L"); //axis+markers (red circles)
//
    n= 92;
    printf("Ep= %13.6e\n",Ep[n]);
    for (j=0; j<nee; j++)
	TestSED[j]= K*SED[n][j];
//
    grp2 = new TGraph(nee,Ee,TestSED);
    grp2->SetLineColor(3);		//for line
    grp2->SetLineStyle(9);		//for line
    grp2->SetLineWidth(2);		//mode
    grp2->Draw("L"); //axis+markers (red circles)
//
    n= 85;
    printf("Ep= %13.6e\n",Ep[n]);
    for (j=0; j<nee; j++)
	TestSED[j]= K*SED[n][j];
//
    grp3 = new TGraph(nee,Ee,TestSED);
    grp3->SetLineColor(2);		//for line
    grp3->SetLineStyle(9);		//for line
    grp3->SetLineWidth(2);		//mode
    grp3->Draw("L"); //axis+markers (red circles)
//
    n= 74;
    printf("Ep= %13.6e\n",Ep[n]);
    for (j=0; j<nee; j++)
	TestSED[j]= K*SED[n][j];
//
    grp4 = new TGraph(nee,Ee,TestSED);
    grp4->SetLineColor(1);		//for line
    grp4->SetLineStyle(9);		//for line
    grp4->SetLineWidth(2);		//mode
    grp4->Draw("L"); //axis+markers (red circles)
//
    c1->Update();
    c1->GetFrame()->SetFillColor(0);
    c1->GetFrame()->SetBorderMode(0);
    c1->GetFrame()->SetBorderSize(0);
    c1->SaveAs("Fig03.eps");
    c1->SaveAs("Fig03.jpg");
    if (gSystem->ProcessEvents()) break;
    c1->Modified();
}
