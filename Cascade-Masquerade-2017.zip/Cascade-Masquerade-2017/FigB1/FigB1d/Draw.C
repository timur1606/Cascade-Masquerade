#include "stdio.h"
#include "stdlib.h"
#include "math.h"
#include "TStyle.h"
#include "TCanvas.h"
#include "TH2F.h"
#include "TGraph.h"

void Draw()
{
    TCanvas *c;
// 1. Define constants
   const Int_t NMax= 100;
// 2. Define variables
    int i;
    double rd,k;
    FILE *fp;
// 3. primary model spectrum
    Double_t PrimE[NMax],PrimNum[NMax],PrimSED[NMax];	//SED= E^{2}*dN/dE
    Double_t ErrPrimE[NMax],ErrPrimSED[NMax];
//absorbed spectrum
    Double_t AbsE[NMax],AbsNum[NMax],AbsSED[NMax];	//SED= E^{2}*dN/dE
    Double_t ErrAbsE[NMax],ErrAbsSED[NMax];
//cascade component
    Double_t CascE[NMax],CascNum[NMax],CascSED[NMax];	//SED= E^{2}*dN/dE
    Double_t ErrCascE[NMax],ErrCascSED[NMax];
// 4. Init
    gROOT->Reset();
    gStyle->SetOptStat(0);
    gStyle->SetPalette(1);
    gStyle->SetCanvasColor(1);
    gStyle->SetFrameFillColor(1);
//    c = new TCanvas("c1","",10,10,1000,800);
    c = new TCanvas("c","Exposure",0,0,1000,800);
    c->GetFrame()->SetBorderMode(-1);
    c->SetFillColor(0);
    c->SetLogx();
    c->SetLogy();
//primary SED
    fp= fopen("log-1e5-prim","r");
    for (i=0; i<NMax; i++)
    {
	fscanf(fp,"%lf",&rd); PrimE[i]  = rd;
	fscanf(fp,"%lf",&rd); PrimSED[i]= rd;
	fscanf(fp,"%lf",&rd); PrimNum[i]= rd;
	ErrPrimE[i]= 0.0;
	ErrPrimSED[i]= 0.0;
	if (PrimNum[i]>0.5)
	    ErrPrimSED[i]= (1.0/sqrt(PrimNum[i]))*PrimSED[i];
    }
	fclose(fp);
//absorbed SED
    fp= fopen("log-1e5-primabs","r");
    for (i=0; i<NMax; i++)
    {
	fscanf(fp,"%lf",&rd); AbsE[i]= rd;
	fscanf(fp,"%lf",&rd); AbsSED[i]= rd;
	fscanf(fp,"%lf",&rd); AbsNum[i]= rd;
	ErrAbsE[i]= 0.0;
	ErrAbsSED[i]= 0.0;
	if (AbsNum[i]>0.5)
	    ErrAbsSED[i]= (1.0/sqrt(AbsNum[i]))*AbsSED[i];
    }
    fclose(fp);
//cascade SED
    fp= fopen("log-1e5-casc","r");
    for (i=0; i<NMax; i++)
    {
	fscanf(fp,"%lf",&rd); CascE[i]= rd;
	fscanf(fp,"%lf",&rd); CascSED[i]= rd;
	fscanf(fp,"%lf",&rd); CascNum[i]= rd;
	ErrCascE[i]= 0.0;
	ErrCascSED[i]= 0.0;
	if (CascNum[i]>0.5)
	    ErrCascSED[i]= (1.0/sqrt(CascNum[i]))*CascSED[i];
    }
    fclose(fp);
//normalize
    double KNorm;
    KNorm= 1.0e-40;
    for (i=0; i<NMax; i++)
    {
	if (PrimSED[i]>KNorm)
	    KNorm= PrimSED[i];
    }
    for (i=0; i<NMax; i++)
    {
	PrimSED[i]   = PrimSED[i]/KNorm;
	ErrPrimSED[i]= ErrPrimSED[i]/KNorm;
	AbsSED[i]    = AbsSED[i]/KNorm;
	ErrAbsSED[i] = ErrAbsSED[i]/KNorm;
	CascSED[i]   = CascSED[i]/KNorm;
	ErrCascSED[i]= ErrCascSED[i]/KNorm;
    }
//total (absorbed+cascade) SED
// 6. Draw histogram to zoom graph
    h= new TH2F("","",30,1.0e8,2.0e14,30,1.0e-4,2.0);
    h->SetTitle("");
    h->GetXaxis()->SetTitleOffset(1.2);
    h->GetYaxis()->SetTitleOffset(1.2);
    h->GetXaxis()->SetTitle("E [eV]");
    h->GetYaxis()->SetTitle("SED [arb. units]");
    h->SetStats(kFALSE);
    h->Draw();
// 8. Draw
    GrPrim = new TGraphErrors(NMax,PrimE,PrimSED,ErrPrimE,ErrPrimSED);
    GrPrim->SetLineColor(1);
    GrPrim->SetLineWidth(2);
    GrPrim->Draw("L");
//
    GrAbs = new TGraphErrors(NMax,AbsE,AbsSED,ErrAbsE,ErrAbsSED);
    GrAbs->SetLineColor(2);
    GrAbs->SetLineWidth(2);
    GrAbs->Draw("L");
//
    GrCasc = new TGraphErrors(NMax,CascE,CascSED,ErrCascE,ErrCascSED);
    GrCasc->SetLineColor(4);
    GrCasc->SetLineWidth(2);
    GrCasc->Draw("L");
//
    c->Update();
    c->GetFrame()->SetFillColor(0);
    c->GetFrame()->SetBorderMode(0);
    c->GetFrame()->SetBorderSize(0);
    c->SaveAs("FigB1d.eps");
    c->SaveAs("FigB1d.jpg");
    if (gSystem->ProcessEvents()) break;
    c->Modified();
}
