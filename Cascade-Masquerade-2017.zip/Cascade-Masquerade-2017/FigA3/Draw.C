{
#include "stdio.h"
#include "stdlib.h"
#include "math.h"

    gROOT->Reset();
    gStyle->SetOptStat(0);
    gStyle->SetPalette(1);
    gStyle->SetCanvasColor(1);
    gStyle->SetFrameFillColor(1);
    TCanvas *c1 = new TCanvas("c1","Diffuse Gamma Spectra",10,10,1100,900);
    c1->GetFrame()->SetBorderMode(-1);
    c1->SetFillColor(0);
    c1->SetLogx();
//
    const Int_t ne= 100;
    const Double_t smalld= 1.0e-40;
    int i;
    double rd;
    double SED[ne];
//
    double Eg1[ne],SEDg1[ne];
    double Eg2[ne],SEDg2[ne];
    double Eg3[ne],SEDg3[ne];
    double Eg4[ne],SEDg4[ne];
    double Eg5[ne],SEDg5[ne];
//
    double Ep1[ne],SEDp1[ne];
    double Ep2[ne],SEDp2[ne];
    double Ep3[ne],SEDp3[ne];
    double Ep4[ne],SEDp4[ne];
//
    FILE *fp;
    h= new TH2F("","",30,1.0e-2,5.0e1,30,0.7,1.5);
    h->SetTitle("");
    h->GetXaxis()->SetTitle("E [TeV]");
    h->GetYaxis()->SetTitle("R_{S}");
    h->GetXaxis()->SetTitleOffset(1.0);
    h->GetYaxis()->SetTitleOffset(1.0);
    h->SetStats(kFALSE);
    h->Draw();
//read data
    fp= fopen("Gamma-1.0e14","r");
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Eg1[i]= 1.0e-12*rd;
	fscanf(fp,"%lf",&rd); SEDg1[i]= rd;
    }
    fclose(fp);
//
    fp= fopen("Gamma-1.0e15","r");
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Eg2[i]= 1.0e-12*rd;
	fscanf(fp,"%lf",&rd); SEDg2[i]= rd;
	SED[i]= rd;
    }
    fclose(fp);
//
    fp= fopen("Gamma-1.0e16","r");
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Eg3[i]= 1.0e-12*rd;
	fscanf(fp,"%lf",&rd); SEDg3[i]= rd;
    }
    fclose(fp);
//
    fp= fopen("Gamma-1.0e17","r");
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Eg4[i]= 1.0e-12*rd;
	fscanf(fp,"%lf",&rd); SEDg4[i]= rd;
    }
    fclose(fp);
//
    fp= fopen("Gamma-1.0e18","r");
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Eg5[i]= 1.0e-12*rd;
	fscanf(fp,"%lf",&rd); SEDg5[i]= rd;
    }
    fclose(fp);
//
    fp= fopen("Positron-1.0e14","r");
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Ep1[i]= 1.0e-12*rd;
	fscanf(fp,"%lf",&rd); SEDp1[i]= rd;
    }
    fclose(fp);
//
    fp= fopen("Positron-1.0e15","r");
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Ep2[i]= 1.0e-12*rd;
	fscanf(fp,"%lf",&rd); SEDp2[i]= rd;
    }
    fclose(fp);
//
    fp= fopen("Positron-1.0e16","r");
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Ep3[i]= 1.0e-12*rd;
	fscanf(fp,"%lf",&rd); SEDp3[i]= rd;
    }
    fclose(fp);
//
    for (i=0; i<ne; i++)
    {
	if (fabs(SED[i])>smalld)
	{
	    if (fabs(SEDg1[i])>smalld) SEDg1[i]= SEDg1[i]/SED[i];
	    else SEDg1[i]= 1.0e-6;
	    if (fabs(SEDg2[i])>smalld) SEDg2[i]= SEDg2[i]/SED[i];
	    else SEDg2[i]= 1.0e-6;
	    if (fabs(SEDg3[i])>smalld) SEDg3[i]= SEDg3[i]/SED[i];
	    else SEDg3[i]= 1.0e-6;
	    if (fabs(SEDg4[i])>smalld) SEDg4[i]= SEDg4[i]/SED[i];
	    else SEDg4[i]= 1.0e-6;
	    if (fabs(SEDg5[i])>smalld) SEDg5[i]= SEDg5[i]/SED[i];
	    else SEDg5[i]= 1.0e-6;
//
	    if (fabs(SEDp1[i])>smalld) SEDp1[i]= SEDp1[i]/SED[i];
	    else SEDp1[i]= 1.0e-6;
	    if (fabs(SEDp2[i])>smalld) SEDp2[i]= SEDp2[i]/SED[i];
	    else SEDp2[i]= 1.0e-6;
	    if (fabs(SEDp3[i])>smalld) SEDp3[i]= SEDp3[i]/SED[i];
	    else SEDp3[i]= 1.0e-6;
	}
	else
	{
	    SEDg1[i]= 1.0e-6;
	    SEDg2[i]= 1.0e-6;
	    SEDg3[i]= 1.0e-6;
	    SEDg4[i]= 1.0e-6;
	    SEDg5[i]= 1.0e-6;
//
	    SEDp1[i]= 1.0e-6;
	    SEDp2[i]= 1.0e-6;
	    SEDp3[i]= 1.0e-6;
	}
    }
//
    grg1 = new TGraph(ne,Eg1,SEDg1);
    grg1->SetLineColor(1);
    grg1->SetLineWidth(2);
    grg1->Draw("L");
//
    grg2 = new TGraph(ne,Eg2,SEDg2);
    grg2->SetLineColor(2);
    grg2->SetLineWidth(2);
    grg2->Draw("L");
//
    grg3 = new TGraph(ne,Eg3,SEDg3);
    grg3->SetLineColor(3);
    grg3->SetLineWidth(2);
    grg3->Draw("L");
//
    grg4 = new TGraph(ne,Eg4,SEDg4);
    grg4->SetLineColor(4);
    grg4->SetLineWidth(2);
    grg4->Draw("L");
//
    grg5 = new TGraph(ne,Eg5,SEDg5);
    grg5->SetLineColor(6);
    grg5->SetLineWidth(2);
    grg5->Draw("L");
//
    grp1 = new TGraph(ne,Ep1,SEDp1);
    grp1->SetLineColor(1);
    grp1->SetLineStyle(9);
    grp1->SetLineWidth(2);
    grp1->Draw("L");
//
    grp2 = new TGraph(ne,Ep2,SEDp2);
    grp2->SetLineColor(2);
    grp2->SetLineStyle(9);
    grp2->SetLineWidth(2);
    grp2->Draw("L");
//
    c1->Update();
    c1->GetFrame()->SetFillColor(0);
    c1->GetFrame()->SetBorderMode(0);
    c1->GetFrame()->SetBorderSize(0);
    c1->SaveAs("FigA3.eps");
    c1->SaveAs("FigA3.jpg");
    if (gSystem->ProcessEvents()) break;
    c1->Modified();
}
