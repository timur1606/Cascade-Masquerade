{
#include "stdio.h"
#include "stdlib.h"
#include "math.h"
#include "string.h"
    gROOT->Reset();
    gStyle->SetOptStat(0);
    gStyle->SetPalette(1);
    gStyle->SetCanvasColor(1);
    gStyle->SetFrameFillColor(1);
    TCanvas *c1 = new TCanvas("c1","Exposure",0,0,1000,800);
    c1->GetFrame()->SetBorderMode(-1);
    c1->SetFillColor(0);
    c1->SetLogx();
    c1->SetLogy();
//
    const Int_t n= 100;
    int i;
    double rd;
    Double_t Lambda1[n],Spec1[n];
    Double_t Lambda2[n],Spec2[n];
    Double_t Lambda3[n],Spec3[n];
    Double_t Lambda4[n],Spec4[n];
    Double_t Lambda5[n],Spec5[n];
    Double_t Lambda6[n],Spec6[n];
    FILE *fp;
//1. read data
    fp= fopen("log-1e12-1e8-1e5","r");
    for (i=0; i<n; i++)
    {
        fscanf(fp,"%lf",&rd); Lambda1[i]= 1.0e-12*rd;
        fscanf(fp,"%lf",&rd); Spec1[i]= (1.0/1.552220)*1.0e-14*1.0e3*rd;
        printf("%13.6e %13.6e\n",Lambda1[i],Spec1[i]);
    }
    fclose(fp);
//
    fp= fopen("log-3e12-1e8-1e5","r");
    for (i=0; i<n; i++)
    {
        fscanf(fp,"%lf",&rd); Lambda2[i]= 1.0e-12*rd;
        fscanf(fp,"%lf",&rd); Spec2[i]= (1.0/1.552220)*1.0e-14*1.0e3*rd/3.0;
    }
    fclose(fp);
//
    fp= fopen("log-1e13-1e8-1e4","r");
    for (i=0; i<n; i++)
    {
        fscanf(fp,"%lf",&rd); Lambda3[i]= 1.0e-12*rd;
        fscanf(fp,"%lf",&rd); Spec3[i]= (1.0/1.552220)*1.0e-14*1.0e2*rd;
    }
    fclose(fp);
//
    fp= fopen("log-3e13-1e8-1e4","r");
    for (i=0; i<n; i++)
    {
        fscanf(fp,"%lf",&rd); Lambda4[i]= 1.0e-12*rd;
        fscanf(fp,"%lf",&rd); Spec4[i]= (1.0/1.552220)*1.0e-14*1.0e2*rd/3.0;
    }
    fclose(fp);
//
    fp= fopen("log-1e14-1e8-1e4","r");
    for (i=0; i<n; i++)
    {
        fscanf(fp,"%lf",&rd); Lambda5[i]= 1.0e-12*rd;
        fscanf(fp,"%lf",&rd); Spec5[i]= (1.0/1.552220)*1.0e-14*10.0*rd;
    }
    fclose(fp);
//
    fp= fopen("log-1e15-1e8-1e3","r");
    for (i=0; i<n; i++)
    {
        fscanf(fp,"%lf",&rd); Lambda6[i]= 1.0e-12*rd;
        fscanf(fp,"%lf",&rd); Spec6[i]= (1.0/1.552220)*1.0e-14*rd;
    }
    fclose(fp);
//
    h= new TH2F("","",30,1e-4,1e2,30,2.0e-3,2.0);
    h->SetTitle("");
    h->GetXaxis()->SetTitle("E [TeV]");
    h->GetYaxis()->SetTitle("SED [arb. units]");
    h->GetXaxis()->SetTitleOffset(1.4);
    h->GetYaxis()->SetTitleOffset(1.0);
    h->SetStats(kFALSE);
    h->Draw();
//
    gr1 = new TGraph(n,Lambda1,Spec1);
    gr1->SetMarkerStyle(8); //circles
    gr1->SetMarkerColor(1); //black
    gr1->SetMarkerSize(1.0); //
    gr1->Draw("P"); //points
//
    gr2 = new TGraph(n,Lambda2,Spec2);
    gr2->SetMarkerStyle(8);
    gr2->SetMarkerColor(2);
    gr2->SetMarkerSize(1.0);
    gr2->Draw("P"); //points
//
    gr3 = new TGraph(n,Lambda3,Spec3);
    gr3->SetMarkerStyle(8);
    gr3->SetMarkerColor(3);
    gr3->SetMarkerSize(1.0);
    gr3->Draw("P"); //points
//
    gr4 = new TGraph(n,Lambda4,Spec4);
    gr4->SetMarkerStyle(8);
    gr4->SetMarkerColor(4);
    gr4->SetMarkerSize(1.0)
    gr4->Draw("P"); //points
//
    gr5 = new TGraph(n,Lambda5,Spec5);
    gr5->SetMarkerStyle(8);
    gr5->SetMarkerColor(7);
    gr5->SetMarkerSize(1.0);
    gr5->Draw("P"); //points
//
    gr6 = new TGraph(n,Lambda6,Spec6);
    gr6->SetMarkerStyle(8);
    gr6->SetMarkerColor(6);
    gr6->SetMarkerSize(1.0);
    gr6->Draw("P"); //points
//
    c1->Update();
    c1->GetFrame()->SetFillColor(0);
    c1->GetFrame()->SetBorderMode(0);
    c1->GetFrame()->SetBorderSize(0);
    c1->SaveAs("Fig01.eps");
    c1->SaveAs("Fig01.jpg");
    if (gSystem->ProcessEvents()) break;
    c1->Modified();
}
