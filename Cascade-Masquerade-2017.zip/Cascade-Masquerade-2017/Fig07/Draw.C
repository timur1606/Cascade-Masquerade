{
#include "stdio.h"
#include "stdlib.h"
#include "math.h"

    gROOT->Reset();
    gStyle->SetOptStat(0);
    gStyle->SetPalette(1);
    gStyle->SetCanvasColor(1);
    gStyle->SetFrameFillColor(1);
    TCanvas *c1 = new TCanvas("c1","Diffuse Gamma Spectra",10,10,1100,900);
    c1->GetFrame()->SetBorderMode(-1);
    c1->SetFillColor(0);
    c1->SetLogx();
    c1->SetLogy();
//
    const Int_t nz= 100;
    int i;
    double rd,K,KE;
    double z1[nz],w1[nz];
    double z11[nz],w11[nz],w12[nz];
    double z2[nz],w2[nz];
    double z21[nz],w21[nz],w22[nz];
    double z3[nz],w3[nz];
    double z31[nz],w31[nz],w32[nz];
    double z4[nz],w4[nz];
    double z41[nz],w41[nz],w42[nz];
    FILE *fp;
//
    h= new TH2F("","",30,1.0e-2,100.0,30,1.0e-2,2.0);
    h->SetTitle("");
    h->GetXaxis()->SetTitle("E [TeV]");
    h->GetYaxis()->SetTitle("SED [arb. units]");
    h->GetXaxis()->SetTitleOffset(1.2);
    h->GetYaxis()->SetTitleOffset(1.2);
    h->SetStats(kFALSE);
    h->Draw();
//
    K= 1.0e-36;
    KE= 1.0e-12;
//
    fp= fopen("Universal-10EeV","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
//
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
//
    for (i=0; i<nz; i++)
    {
	fscanf(fp,"%lf",&rd); z1[i]= KE*rd;
	fscanf(fp,"%lf",&rd); w1[i]= 0.915*3.0e-32*rd/1.240029;
    }
    fclose(fp);
//
    gr1 = new TGraph(nz,z1,w1);
    gr1->SetLineColor(1);
    gr1->SetLineWidth(2);
    gr1->Draw("L");
//
    fp= fopen("Universal-10EeV-006","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
//
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
//
    for (i=0; i<nz; i++)
    {
	fscanf(fp,"%lf",&rd); z11[i]= KE*rd;
	fscanf(fp,"%lf",&rd); w12[i]= 0.915*3.0e-32*rd/1.240029;
	w11[i]= w1[i]-w12[i];
    }
    fclose(fp);
//
    gr11 = new TGraph(nz,z11,w11);
    gr11->SetLineColor(1);
    gr11->SetLineStyle(9);
    gr11->SetLineWidth(2);
    gr11->Draw("L");
//
    gr12 = new TGraph(nz,z1,w12);
    gr12->SetLineColor(1);
    gr12->SetLineStyle(10);
    gr12->SetLineWidth(2);
    gr12->Draw("L");
//
    fp= fopen("Universal-30EeV","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
//
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
//
    for (i=0; i<nz; i++)
    {
	fscanf(fp,"%lf",&rd); z2[i]= KE*rd;
	fscanf(fp,"%lf",&rd); w2[i]= 0.955*8.0e-33*rd/1.240029;
    }
    fclose(fp);
//
    gr2 = new TGraph(nz,z2,w2);
    gr2->SetLineColor(2);
    gr2->SetLineWidth(2);
    gr2->Draw("L");
//
    fp= fopen("Universal-30EeV-006","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
//
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
//
    for (i=0; i<nz; i++)
    {
	fscanf(fp,"%lf",&rd); z21[i]= KE*rd;
	fscanf(fp,"%lf",&rd); w22[i]= 0.955*8.0e-33*rd/1.240029;
	w21[i]= w2[i]-w22[i];
    }
    fclose(fp);
//
    gr21 = new TGraph(nz,z21,w21);
    gr21->SetLineColor(2);
    gr21->SetLineStyle(9);
    gr21->SetLineWidth(2);
    gr21->Draw("L");
//
    gr22 = new TGraph(nz,z21,w22);
    gr22->SetLineColor(2);
    gr22->SetLineStyle(10);
    gr22->SetLineWidth(2);
    gr22->Draw("L");
//
    fp= fopen("Universal-50EeV","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
//
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
//
    for (i=0; i<nz; i++)
    {
	fscanf(fp,"%lf",&rd); z3[i]= KE*rd;
	fscanf(fp,"%lf",&rd); w3[i]= 0.935*5.0e-33*rd/1.240029;
	printf("%13.6e %13.6e\n",z1[i],w1[i]);
    }
    fclose(fp);
//
    gr3 = new TGraph(nz,z3,w3);
    gr3->SetLineColor(3);
    gr3->SetLineWidth(2);
    gr3->Draw("L");
//
    fp= fopen("Universal-50EeV-006","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
//
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
//
    for (i=0; i<nz; i++)
    {
	fscanf(fp,"%lf",&rd); z31[i]= KE*rd;
	fscanf(fp,"%lf",&rd); w32[i]= 0.935*5.0e-33*rd/1.240029;
	w31[i]= w3[i]-w32[i];
	printf("%13.6e %13.6e\n",z1[i],w1[i]);
    }
    fclose(fp);
//
    gr31 = new TGraph(nz,z31,w31);
    gr31->SetLineColor(3);
    gr31->SetLineStyle(9);
    gr31->SetLineWidth(2);
    gr31->Draw("L");
//
    gr32 = new TGraph(nz,z31,w32);
    gr32->SetLineColor(3);
    gr32->SetLineStyle(10);
    gr32->SetLineWidth(2);
    gr32->Draw("L");
//
    fp= fopen("Universal-100EeV","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
//
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
//
    for (i=0; i<nz; i++)
    {
	fscanf(fp,"%lf",&rd); z4[i]= KE*rd;
	fscanf(fp,"%lf",&rd); w4[i]= 0.825*3.0e-33*rd/1.240029;
    }
    fclose(fp);
//
    gr4 = new TGraph(nz,z4,w4);
    gr4->SetLineColor(4);
    gr4->SetLineWidth(2);
    gr4->Draw("L");
//
    fp= fopen("Universal-100EeV-006","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
//
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
    fscanf(fp,"%lf",&rd);
//
    for (i=0; i<nz; i++)
    {
	fscanf(fp,"%lf",&rd); z41[i]= KE*rd;
	fscanf(fp,"%lf",&rd); w42[i]= 0.825*3.0e-33*rd/1.240029;
	w41[i]= w4[i]-w42[i];
    }
    fclose(fp);
//
    gr41 = new TGraph(nz,z41,w41);
    gr41->SetLineColor(4);
    gr41->SetLineStyle(9);
    gr41->SetLineWidth(2);
    gr41->Draw("L");
//
    gr42 = new TGraph(nz,z41,w42);
    gr42->SetLineColor(4);
    gr42->SetLineStyle(10);
    gr42->SetLineWidth(2);
    gr42->Draw("L");
//
    c1->Update();
    c1->GetFrame()->SetFillColor(0);
    c1->GetFrame()->SetBorderMode(0);
    c1->GetFrame()->SetBorderSize(0);
    c1->SaveAs("Fig07.eps");
    c1->SaveAs("Fig07.jpg");
    if (gSystem->ProcessEvents()) break;
    c1->Modified();
}
