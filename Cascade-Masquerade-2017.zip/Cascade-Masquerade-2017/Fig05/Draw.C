{
#include "stdio.h"
#include "stdlib.h"
#include "math.h"

    gROOT->Reset();
    gStyle->SetOptStat(0);
    gStyle->SetPalette(1);
    gStyle->SetCanvasColor(1);
    gStyle->SetFrameFillColor(1);
    TCanvas *c1 = new TCanvas("c1","Diffuse Gamma Spectra",10,10,1100,900);
    c1->GetFrame()->SetBorderMode(-1);
    c1->SetFillColor(0);
//
    const Int_t nz= 18600;
    int i;
    double rd;
    double z1[nz],k1[nz];
    double z2[nz],k2[nz];
    double z3[nz],k3[nz];
    double z4[nz],k4[nz];
    FILE *fp;
//
    h= new TH2F("","",30,0.0,0.2,30,0.4,1.1);
    h->SetTitle("");
    h->GetXaxis()->SetTitle("z");
    h->GetYaxis()->SetTitle("K_{em}(z)");
    h->GetXaxis()->SetTitleOffset(1.0);
    h->GetYaxis()->SetTitleOffset(1.1);
    h->SetStats(kFALSE);
    h->Draw();
//
    fp= fopen("Kem-Z-0186-E-1e19","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
    fscanf(fp,"%lf",&rd); //z
    fscanf(fp,"%lf",&rd); //E_{p0}
    for (i=0; i<nz; i++)
    {
	fscanf(fp,"%lf",&rd); z1[i]= rd;
	fscanf(fp,"%lf",&rd); k1[i]= rd;
    }
    fclose(fp);
//
    gr1 = new TGraph(nz,z1,k1);
    gr1->SetLineColor(1);
    gr1->SetLineWidth(2);
    gr1->Draw("L");
//
    fp= fopen("Kem-Z-0186-E-3e19","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
    fscanf(fp,"%lf",&rd); //z
    fscanf(fp,"%lf",&rd); //E_{p0}
    for (i=0; i<nz; i++)
    {
	fscanf(fp,"%lf",&rd); z2[i]= rd;
	fscanf(fp,"%lf",&rd); k2[i]= rd;
    }
    fclose(fp);
//
    gr2 = new TGraph(nz,z2,k2);
    gr2->SetLineColor(2);
    gr2->SetLineWidth(2);
    gr2->Draw("L");
//
    fp= fopen("Kem-Z-0186-E-5e19","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
    fscanf(fp,"%lf",&rd); //z
    fscanf(fp,"%lf",&rd); //E_{p0}
    for (i=0; i<nz; i++)
    {
	fscanf(fp,"%lf",&rd); z3[i]= rd;
	fscanf(fp,"%lf",&rd); k3[i]= rd;
    }
    fclose(fp);
//
    gr3 = new TGraph(nz,z3,k3);
    gr3->SetLineColor(3);
    gr3->SetLineWidth(2);
    gr3->Draw("L");
//
    fp= fopen("Kem-Z-0186-E-1e20","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
    fscanf(fp,"%lf",&rd); //z
    fscanf(fp,"%lf",&rd); //E_{p0}
    for (i=0; i<nz; i++)
    {
	fscanf(fp,"%lf",&rd); z4[i]= rd;
	fscanf(fp,"%lf",&rd); k4[i]= rd;
    }
    fclose(fp);
//
    gr4 = new TGraph(nz,z4,k4);
    gr4->SetLineColor(4);
    gr4->SetLineWidth(2);
    gr4->Draw("L");
//
    c1->Update();
    c1->GetFrame()->SetFillColor(0);
    c1->GetFrame()->SetBorderMode(0);
    c1->GetFrame()->SetBorderSize(0);
    c1->SaveAs("Fig05.eps");
    c1->SaveAs("Fig05.jpg");
    if (gSystem->ProcessEvents()) break;
    c1->Modified();
}
