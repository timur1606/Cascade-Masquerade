{
#include "stdio.h"
#include "stdlib.h"
#include "math.h"
// 1. Init
    gROOT->Reset();
    gStyle->SetOptStat(0);
    gStyle->SetPalette(1);
    gStyle->SetCanvasColor(1);
    gStyle->SetFrameFillColor(1);
    TCanvas *c1 = new TCanvas("c1","Exp. and Model Gamma Spectra",10,10,1100,900);
    c1->GetFrame()->SetBorderMode(-1);
    c1->SetFillColor(0);
    c1->SetLogx();
    c1->SetLogy();
// 2. Define constants
    const Int_t NExpMax= 100;
    const Int_t NModMax= 1000;
    const Int_t PrintFlag= 0;
    const Int_t FermiN= 4;
    const Int_t NModMax2= 146;
// 3. Define variables
    int i,NExp,NExp2,NMod,NMod2;
    double rd,K,K2;
    double statp,statm,sysp,sysm;
    double chisq,dSED;
    FILE *fp;
// exp. data 1
    Double_t EExp[NExpMax],SEDExp[NExpMax]; //exp. data
    Double_t EErr[NExpMax],SEDErr[NExpMax];
    Double_t SysExpP[NExpMax],SysExpM[NExpMax];
// model data
    Double_t EMod[NModMax],SEDMod[NModMax]; //model
    Double_t SEDAbs[NModMax],SEDCasc[NModMax],SEDPrim[NModMax];
    Double_t SEDPrim2[NModMax];
// exp. data 2
    Double_t EExp2[FermiN],SEDExp2[FermiN]; //exp. data
    Double_t EExp2l[FermiN],SEDExp2l[FermiN];
    Double_t EExp2r[FermiN],SEDExp2r[FermiN];
    Double_t EExp2b[FermiN],SEDExp2b[FermiN];
    Double_t EExp2t[FermiN],SEDExp2t[FermiN];
// model data 2
    Double_t EMod2[NModMax],SEDMod2[NModMax]; //model
// 4. Init variables
// init exp. data
    for (i=0; i<NExpMax; i++)
    {
	EExp[i]  = 0.0;
	SEDExp[i]= 0.0;
//
	EErr[i]= 0.0;
	SEDErr[i]= 0.0;
//
	SysExpP[i]= 0.0;
	SysExpM[i]= 0.0;
    }
// init model data
    for (i=0; i<NModMax; i++)
    {
	EMod[i]  = 0.0;
	SEDMod[i]= 0.0;
	SEDAbs[i]= 0.0;
	SEDCasc[i]= 0.0;
	SEDPrim[i]= 0.0;
    }
// 5. read exp. data 1
    fp= fopen("070-Aharonian07c","r");
    if (fp==NULL)
    {
	printf("Error: exp. input file not found!\n");
	return;
    }
    fscanf(fp,"%d",&NExp);
    if (PrintFlag>0)
	printf("NExp= %4d\n",NExp);
    for (i=0; i<NExp; i++)
    {
	fscanf(fp,"%lf",&rd);
	EExp[i]= rd;
	fscanf(fp,"%lf",&rd); //emin
	fscanf(fp,"%lf",&rd);
	fscanf(fp,"%lf",&rd);
	SEDExp[i]= EExp[i]*EExp[i]*rd; //E^2*dN/dE
//
	fscanf(fp,"%lf",&rd); //statistical uncertainty
	statp= rd;
	fscanf(fp,"%lf",&rd);
	statm= fabs(rd);
	SEDErr[i]= EExp[i]*EExp[i]*rd;
	fscanf(fp,"%lf",&rd); //systematic  uncertainty +
	sysp= rd;
	SysExpP[i]= EExp[i]*EExp[i]*sqrt(statp*statp+sysp*sysp);
	fscanf(fp,"%lf",&rd); //systematic  uncertainty -
	sysm= fabs(rd);
	SysExpM[i]= EExp[i]*EExp[i]*sqrt(statm*statm+sysm*sysm);
	printf("%8.6e %8.6e  %8.6e %8.6e\n",EExp[i],SEDExp[i],SysExpM[i],SysExpP[i]);
    }
    fclose(fp);
// 6. read model data
    K= 3.0e-16/1.7;
    fp= fopen("Vovk","r");
    if (fp==NULL)
    {
	printf("Error: model input file not found!\n");
	return;
    }
    fscanf(fp,"%d",&NMod);
    if (PrintFlag>0)
	printf("NMod= %4d\n",NMod);
    for (i=0; i<NMod; i++)
    {
	fscanf(fp,"%lf",&rd);
	EMod[i]= rd;
	fscanf(fp,"%lf",&rd);
	SEDMod[i]=K*rd;
	fscanf(fp,"%lf",&rd);
	SEDAbs[i]=K*rd;
	if (EMod[i]<0.1/(1.186))
	{
	    dSED= 2.5e3*K*pow(EMod[i],0.8)/pow(0.1/(1.186),0.8);
	    SEDAbs[i]+= dSED;
	    SEDMod[i]+= dSED;
	}
	fscanf(fp,"%lf",&rd);
	SEDCasc[i]=K*rd;
	fscanf(fp,"%lf",&rd);
	SEDPrim[i]=K*rd;
	if (PrintFlag>0)
	    printf("%8.6e %8.6e\n",EMod[i],SEDMod[i]);
    }
    fclose(fp);
    for (i=0; i<NMod; i++)
	SEDPrim2[i]= 3.4e-12*pow(EMod[i],0.8)*exp(-EMod[i]/5.0);
// read exp 2
    K2= 1.0e-12;
    fp= fopen("Vovk-Data","r");
    if (fp==NULL)
    {
	printf("Error: data input file not found!\n");
	return;
    }
    for (i=0; i<FermiN; i++)
    {
	fscanf(fp,"%lf",&rd);
	EExp2[i]=pow(10,rd)*K2;
	fscanf(fp,"%lf",&rd);
	SEDExp2[i]=pow(10,rd)*K2;
    }
    for (i=0; i<FermiN; i++)
    {
	fscanf(fp,"%lf",&rd);
	EExp2l[i]=EExp2[i]-(pow(10,rd)*K2);
	fscanf(fp,"%lf",&rd);
    }
    for (i=0; i<FermiN; i++)
    {
	fscanf(fp,"%lf",&rd);
	EExp2r[i]=(pow(10,rd)*K2)-EExp2[i];
	fscanf(fp,"%lf",&rd);
    }
    for (i=0; i<FermiN; i++)
    {
	fscanf(fp,"%lf",&rd);
	fscanf(fp,"%lf",&rd);
	SEDExp2b[i]=SEDExp2[i]-(pow(10,rd)*K2);
    }
    for (i=0; i<FermiN; i++)
    {
	fscanf(fp,"%lf",&rd);
	fscanf(fp,"%lf",&rd);
	SEDExp2t[i]=(pow(10,rd)*K2)-SEDExp2[i];
    }
    fclose(fp);
//
    fp= fopen("Vovk-Model","r");
    if (fp==NULL)
    {
	printf("Error: model input file not found!\n");
	return;
    }
    for (i=0; i<NModMax2; i++)
    {
	fscanf(fp,"%lf",&rd);
	EMod2[i]=pow(10,rd)*K2;
	fscanf(fp,"%lf",&rd);
	SEDMod2[i]= pow(10,rd)*K2;
    }
    fclose(fp);
// 7. Draw histogram to zoom graphs
    h= new TH2F("","",30,1.0e-3,30,30,1.0e-15,1.0e-10);
    h->GetXaxis()->SetTitle("E [TeV]");
    h->GetYaxis()->SetTitle("SED [TeVcm^{-2}s^{-1}]");
    h->GetXaxis()->SetTitleOffset(1.4);
    h->GetYaxis()->SetTitleOffset(1.4);
    h->SetStats(kFALSE);
    h->Draw();
// 8. Draw exp. data 1
    GrExp = new TGraphAsymmErrors(NExp,EExp,SEDExp,0,0,SysExpM,SysExpP);
    GrExp->SetLineColor(2);		//for line
    GrExp->SetLineWidth(2);		//mode
    GrExp->SetMarkerColor(2);		//2= red
    GrExp->SetTitle("");
    GrExp->SetMarkerStyle(8);		//8= circles
    GrExp->SetMarkerSize(1.5);
    GrExp->Draw("P"); //axis+markers (red circles)
// 9. Draw model data
    GrMod = new TGraph(NMod,EMod,SEDMod);
    GrMod->SetLineColor(4);		//for line
    GrMod->SetLineWidth(4);		//mode
    GrMod->SetLineStyle(9);		//mode
    GrMod->SetTitle("");
    GrMod->Draw("L"); //markers (blue circles)
//
    GrModAbs = new TGraph(NMod,EMod,SEDAbs);
    GrModAbs->SetLineColor(1);		//for line
    GrModAbs->SetLineWidth(2);		//mode
    GrModAbs->SetTitle("");
    GrModAbs->Draw("L"); //markers (blue circles)
//
    GrModCasc = new TGraph(NMod,EMod,SEDCasc);
    GrModCasc->SetLineColor(3);		//for line
    GrModCasc->SetLineWidth(2);		//mode
    GrModCasc->SetTitle("");
    GrModCasc->Draw("L"); //markers (blue circles)
//
    GrModPrim2 = new TGraph(NMod,EMod,SEDPrim2);
    GrModPrim2->SetLineColor(1);		//for line
    GrModPrim2->SetLineWidth(2);		//mode
    GrModPrim2->SetLineStyle(9);		//mode
    GrModPrim2->Draw("L"); //markers (blue circles)
//
    GrMod = new TGraph(NModMax2,EMod2,SEDMod2);
    GrMod->SetLineColor(6);		//for line
    GrMod->SetLineWidth(2);		//mode
    GrMod->SetTitle("");
    GrMod->Draw("L"); //markers (blue circles)
//
    c1->Update();
    c1->GetFrame()->SetFillColor(0);
    c1->GetFrame()->SetBorderMode(0);
    c1->GetFrame()->SetBorderSize(0);
    c1->SaveAs("FigD1.eps");
    c1->SaveAs("FigD1.jpg");
    if (gSystem->ProcessEvents()) break;
    c1->Modified();
}
