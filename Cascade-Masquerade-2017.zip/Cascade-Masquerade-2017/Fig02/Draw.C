{
#include "stdio.h"
#include "stdlib.h"
#include "math.h"

    gROOT->Reset();
    gStyle->SetOptStat(0);
    gStyle->SetPalette(1);
    gStyle->SetCanvasColor(1);
    gStyle->SetFrameFillColor(1);
    TCanvas *c1 = new TCanvas("c1","Diffuse Gamma Spectra",10,10,1100,900);
    c1->GetFrame()->SetBorderMode(-1);
    c1->SetFillColor(0);
    c1->SetLogx();
    c1->SetLogy();
//
    const Int_t n= 200;
    int i;
    double rd,K;
    FILE *fp;
    Double_t E1[n],Spec1[n];
    Double_t E2[n],Spec2[n];
    Double_t E3[n],Spec3[n];
    Double_t E4[n],Spec4[n];
//
    K= 1.0/5.433847e-35;
    fp= fopen("1.0e18","r");
    if (fp==NULL)
    {
	printf("Error: input file not found!\n");
	return;
    }
    for (i=0; i<n; i++)
    {
	fscanf(fp,"%lf",&rd); E1[i]= rd;
	fscanf(fp,"%lf",&rd); Spec1[i]= K*rd;
    }
    fclose(fp);
//
    fp= fopen("1.0e19","r");
    if (fp==NULL)
    {
	printf("Error: input file2 not found!\n");
	return;
    }
    for (i=0; i<n; i++)
    {
	fscanf(fp,"%lf",&rd); E2[i]= rd;
	fscanf(fp,"%lf",&rd); Spec2[i]= K*rd;
    }
    fclose(fp);
//
    fp= fopen("3.0e19","r");
    if (fp==NULL)
    {
	printf("Error: input file2 not found!\n");
	return;
    }
    for (i=0; i<n; i++)
    {
	fscanf(fp,"%lf",&rd); E3[i]= rd;
	fscanf(fp,"%lf",&rd); Spec3[i]= K*rd;
    }
    fclose(fp);
//
    fp= fopen("1.0e20","r");
    if (fp==NULL)
    {
	printf("Error: input file2 not found!\n");
	return;
    }
    for (i=0; i<n; i++)
    {
	fscanf(fp,"%lf",&rd); E4[i]= rd;
	fscanf(fp,"%lf",&rd); Spec4[i]= K*rd;
    }
    fclose(fp);
//Draw histogram to zoom graphs
    h= new TH2F("","",30,1.0e13,1.0e20,30,1.0e-5,3.0);
    h->SetTitle("");
    h->GetXaxis()->SetTitle("E [eV]");
    h->GetYaxis()->SetTitle("SED [arb. units]");
    h->GetXaxis()->SetTitleOffset(1.2);
    h->GetYaxis()->SetTitleOffset(1.2);
    h->SetStats(kFALSE);
    h->Draw();
//
    gr1 = new TGraph(n,E1,Spec1);
    gr1->SetLineColor(1);		//for line
    gr1->SetLineWidth(2);		//mode
    gr1->Draw("L"); //axis+markers (red circles)
//
    gr2 = new TGraph(n,E2,Spec2);
    gr2->SetLineColor(2);		//for line
    gr2->SetLineWidth(2);		//mode
    gr2->Draw("L"); //axis+markers (red circles)
//
    gr3 = new TGraph(n,E3,Spec3);
    gr3->SetLineColor(3);		//for line
    gr3->SetLineWidth(2);		//mode
    gr3->Draw("L"); //axis+markers (red circles)
//
    gr4 = new TGraph(n,E4,Spec4);
    gr4->SetLineColor(4);		//for line
    gr4->SetLineWidth(2);		//mode
    gr4->Draw("L"); //axis+markers (red circles)
//
    c1->Update();
    c1->GetFrame()->SetFillColor(0);
    c1->GetFrame()->SetBorderMode(0);
    c1->GetFrame()->SetBorderSize(0);
    c1->SaveAs("Fig02.eps");
    c1->SaveAs("Fig02.jpg");
    if (gSystem->ProcessEvents()) break;
    c1->Modified();
}
