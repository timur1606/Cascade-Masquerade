{
#include "stdio.h"
#include "stdlib.h"
#include "math.h"

    gROOT->Reset();
    gStyle->SetOptStat(0);
    gStyle->SetPalette(1);
    gStyle->SetCanvasColor(1);
    gStyle->SetFrameFillColor(1);
    TCanvas *c1 = new TCanvas("c1","Diffuse Gamma Spectra",10,10,1100,900);
    c1->GetFrame()->SetBorderMode(-1);
    c1->SetFillColor(0);
    c1->SetLogx();
    c1->SetLogy();
//
    const Int_t ne= 100;
    int i;
    double rd;
//
    double Eg1[ne],SEDg1[ne];
    double Eg2[ne],SEDg2[ne];
    double Eg3[ne],SEDg3[ne];
    double Eg4[ne],SEDg4[ne];
//
    double Ep1[ne],SEDp1[ne];
    double Ep2[ne],SEDp2[ne];
    double Ep3[ne],SEDp3[ne];
    double Ep4[ne],SEDp4[ne];
//
    FILE *fp;
    h= new TH2F("","",30,1.0e-2,1.0e2,30,1.0e-2,2.0);
    h->SetTitle("");
    h->GetXaxis()->SetTitle("E [TeV]");
    h->GetYaxis()->SetTitle("SED [arb. units]");
    h->GetXaxis()->SetTitleOffset(1.4);
    h->GetYaxis()->SetTitleOffset(1.0);
    h->SetStats(kFALSE);
    h->Draw();
//
    fp= fopen("Gamma-1.0e14","r");
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Eg1[i]= 1.0e-12*rd;
	fscanf(fp,"%lf",&rd); SEDg1[i]= rd/1.065144e18;
    }
    fclose(fp);
    grg1 = new TGraph(ne,Eg1,SEDg1);
    grg1->SetLineColor(1);
    grg1->SetLineWidth(2);
    grg1->Draw("L");
//
    fp= fopen("Gamma-1.0e15","r");
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Eg2[i]= 1.0e-12*rd;
	fscanf(fp,"%lf",&rd); SEDg2[i]= rd/1.065144e18;
    }
    fclose(fp);
    grg2 = new TGraph(ne,Eg2,SEDg2);
    grg2->SetLineColor(2);
    grg2->SetLineWidth(2);
    grg2->Draw("L");
//
    fp= fopen("Positron-1.0e14","r");
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Ep1[i]= 1.0e-12*rd;
	fscanf(fp,"%lf",&rd); SEDp1[i]= rd/1.065144e18;
	printf("%13.6e %13.6e\n",Ep1[i],SEDp1[i]);
    }
    fclose(fp);
    grp1 = new TGraph(ne,Eg1,SEDp1);
    grp1->SetLineColor(1);
    grp1->SetLineStyle(9);
    grp1->SetLineWidth(2);
    grp1->Draw("L");
//
    fp= fopen("Positron-1.0e15","r");
    for (i=0; i<ne; i++)
    {
	fscanf(fp,"%lf",&rd); Ep2[i]= 1.0e-12*rd;
	fscanf(fp,"%lf",&rd); SEDp2[i]= rd/1.065144e18;
    }
    fclose(fp);
    grp2 = new TGraph(ne,Ep2,SEDp2);
    grp2->SetMarkerColor(4);
    grp2->SetMarkerStyle(2);
    grp2->SetMarkerSize(2);
    grp2->Draw("P");
//
    c1->Update();
    c1->GetFrame()->SetFillColor(0);
    c1->GetFrame()->SetBorderMode(0);
    c1->GetFrame()->SetBorderSize(0);
    c1->SaveAs("FigA2.eps");
    c1->SaveAs("FigA2.jpg");
    if (gSystem->ProcessEvents()) break;
    c1->Modified();
}
